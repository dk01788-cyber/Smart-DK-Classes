# Smart DK Classes — Combined Feature Code (19 October 2026)

यह **Source Code Release 1.4.0** है, कोई तैयार/साइन की हुई APK या live deployment नहीं। मौजूदा Blue-White Theme, पुरानी Academic hierarchy, Home Banner, YouTube Video selection और login सुरक्षित रखने के उद्देश्य से नई सुविधाएँ **additive** तरीके से जोड़ी गई हैं।

## आधार Source Versions
- Admin App: v1.3.0 (Android app के local `admin.html` पर आधारित)
- Public Android App: v1.3.2 (native Java screens)
- Website: v7.3 (Cloudflare Pages)
- Backend: मौजूदा Smart DK Classes Supabase project

## बनाए गए बदलाव
1. **Academic Upload**: Class → Subject → Category → Chapter का पुराना flow यथावत।
2. **Direct Upload**: Class/Subject आवश्यक नहीं। GK/Reasoning/Custom Sections में unlimited nesting या General Library में बिना Folder PDF/Video जोड़ें।
3. **Bulk PDF Upload**: एक साथ अनेक PDFs चुनकर एक Destination में upload। Title फ़ाइल नाम से।
4. **Bulk Move**: चयनित PDFs/Video को बिना दोबारा upload किए Direct folders या Academic Category में move करें।
5. **Background Design**: Card Edit में 🎨 Background और अलग Design Studio दोनों जगह से solid/gradient/gallery image। Multiple same-level cards के लिए Apply All और reset।
6. **Card Order**: Root Class + GK/Reasoning/Custom Sections को interleave, और nested cards की position भी ऊपर/नीचे या number से बदलें। Existing locked items को पहले unlock करें।
7. **Mock Test Hub**: अलग top-level home card, optional categories, Admin से draft/publish, per-question marks, negative marking, timer, correct choice, explanation, CSV bulk import।
8. **Instant Result + Answer Review**: Final Submit के बाद total, attempted, correct, wrong, unanswered, accuracy, score और detailed question-wise review। `सभी / सही / गलत / छोड़े हुए` filters; student का selected option, correct answer और explanation (जब Admin अनुमति दे)। Result से Review और वापस Result जाने के बटन। उसी tab के session में page refresh के बाद हाल का Result फिर खुल सकेगा।
9. Student login अभी भी जरूरी नहीं। Site + native app के dedicated WebView quiz page एक ही Supabase backend से काम करते हैं। Main Android app अब भी native रहता है।

## Deploy / Build का क्रम
1. मौजूदा Supabase Database और Storage का backup लें। **पहले staging/backup copy में जाँच** करने की सलाह है।
2. Supabase SQL Editor में `SDKC_2026_10_19_SCHEMA.sql` **एक बार** Run करें। यह नई tables/RLS/functions तथा पुराने `content_structure` पर चार non-destructive background columns जोड़ता है; पुरानी app_content rows नहीं बदलता। नया मुख्य Mock Test card seed होता है।
3. Supabase में पूर्व मौजूद `public-content` bucket का public download URL और admin upload permissions जाँचें (उसी bucket को पुरानी admin app इस्तेमाल करती है)। नई image upload उसी bucket के `backgrounds/` prefix में जाएगी।
4. Website source ZIP का `public` folder Cloudflare Pages पर deploy करें; Pages Functions/other site assets भी वही रखें। इससे `/mock-tests.html` और `/direct.html` लाइव होंगे। Existing main theme/design को replace करके नया theme न लगाएँ।
5. Admin Android source ZIP Android Studio/Gradle में खोलें, `assembleRelease` या `assembleDebug` चलाएँ और अपनी signing key से APK बनाएँ। Admin login के लिए पुराना registered admin account ही उपयोग होगा।
6. Public Android source ZIP build और sign करें। Public app Home में shared backend से नया Mock Test, GK/Reasoning और General Library navigation आएगा। **नए quiz और direct screens वेबसाइट के hosted pages खोलते हैं; पहले website deploy होना जरूरी है।**
7. Admin में Mock Test Manager खोलें, एक Draft Test बनाएँ, प्रश्न जोड़ें, Publish करें। Student website/app पर Start → Final Submit → Result → Review Answers की जाँच करें।

## CSV template
`mock_test_questions_template.csv` शामिल है। Header: `question,optionA,optionB,optionC,optionD,correct,explanation,marks`; correct number **1-based** (1 = A)। CSV में quoted commas/newlines का support है।

## Result का अर्थ
- **Accuracy** = Correct / Attempted × 100 (Attempted 0 होने पर 0%)
- **Score** = सही उत्तरों के marks − गलत उत्तरों की configured negative marking
- **Wrong** = attempted − correct; **Unattempted** = total − attempted
- Detailed review में गलत/सही/छोड़े गए सभी प्रश्नों पर अलग filters हैं।

## महत्वपूर्ण सीमाएँ और QA
- यह code package इस बातचीत में **बनाया गया है**, पर **live Supabase migration / Cloudflare deploy / signed APK install नहीं किया गया**।
- JavaScript syntax और HTML asset link checks किए गए। इस वातावरण में Android Gradle SDK toolchain उपलब्ध नहीं थी, इसलिए APK compile/install का end-to-end परीक्षण नहीं हुआ।
- Public test review के लिए server-side RPC answer key सिर्फ Final Submit response में देता है; questions API सही विकल्प पहले नहीं देता। बिना login वाली public test को **secure/proctored examination** नहीं मानना चाहिए, क्योंकि कोई भी जल्दी submit करके answers देख सकता है।
- Timer browser/WebView में चलता है। Strict server-enforced timing, anti-cheat, long-term attempt history, Leaderboard व student accounts इस release में नहीं हैं।
- Keep old signed APK until updated source has been built, signed, tested, and accepted.
