# Smart DK Classes Website v5.5 — Google AdSense verification

Publisher ID: `ca-pub-1212477578796147`

इस version में:
- Google AdSense script public content pages के `<head>` में जोड़ा गया है।
- `public/ads.txt` बनाया गया है।
- v5.4 का phone-removal, header, banner, legal pages और support email वैसा ही रखा गया है।

Deploy के बाद:
1. वेबसाइट खोलकर source में `ca-pub-1212477578796147` verify करें।
2. `https://smart-dk-classes-web.pages.dev/ads.txt` खोलकर publisher line verify करें।
3. Google AdSense में वापस जाकर site verification / review आगे बढ़ाएँ।
