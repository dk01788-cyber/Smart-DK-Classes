# Smart DK Classes Website v6.1

## इस अपडेट में

- Admin App और Website एक ही Supabase `app_content` data source use करते हैं.
- Admin App से content Add / Edit / Delete / Publish / Hide / App-Website-Both target बदलने पर Website अपने-आप नया data पढ़ती है.
- Supabase Realtime उपलब्ध होने पर बदलाव तुरंत detect होता है.
- Realtime उपलब्ध न होने पर 15-second polling fallback रखा गया है.
- Class -> Subject -> Category screen के category cards अब colorful app-style gradients में हैं.
- Handwritten Notes, Notes, Question Bank, Model Papers, Previous Year Papers, Important Questions, Formula/Revision, Practice Sets और Videos की अलग visual identity है.
- Custom/new categories के लिए भी automatic color variants हैं.

## जरूरी शर्त
Admin App और Website दोनों में वही Supabase project/config होना चाहिए. Admin को `app_content` table में write करना है; Website website/both target वाले published rows पढ़ती है.
