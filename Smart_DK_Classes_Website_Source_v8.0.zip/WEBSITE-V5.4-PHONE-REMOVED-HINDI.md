# Smart DK Classes Website v5.4 — Phone Number Removed

- Public website से mobile/WhatsApp number हटाया गया।
- Contact Us अब email-only support दिखाता है।
- Header contact strip में केवल support email, YouTube और student access note रहेगा।
- Footer Contact में केवल support email रहेगा।
- पुराने Supabase phone value मौजूद होने पर भी website उसे public UI में नहीं दिखाएगी।
- Support email: smartdkclasses.help@gmail.com
