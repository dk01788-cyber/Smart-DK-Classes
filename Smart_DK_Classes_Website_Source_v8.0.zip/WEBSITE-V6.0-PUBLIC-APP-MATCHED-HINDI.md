# Smart DK Classes Website v6.0 — Public App Matched Design

यह version Public Smart DK Classes Android app के final structure/design के अनुसार बनाया गया है।

## Home Page
- Blue-white app-like header
- Search bar
- वही locked banner
- Class 9 / 10 / 11 / 12 cards
- केवल Admin-selected Home videos
- Latest PDFs section हटाया गया
- YouTube latest/Shorts auto-feed Home से पूरी तरह हटाया गया

## Content Flow
Home → Class → Subject → Category → Content

Videos category में:
Class → Subject → Videos → Chapter → Videos

## Video behavior
- Website में embedded YouTube player
- नीचे View on YouTube button
- Home पर केवल `show_on_home = true` videos

## Navigation
Mobile: Home | Classes | Search | Downloads
Desktop: वही मुख्य app navigation top bar में

## Existing backend
Supabase का वही `app_content` backend और `display_target = website/both` rules जारी हैं।
