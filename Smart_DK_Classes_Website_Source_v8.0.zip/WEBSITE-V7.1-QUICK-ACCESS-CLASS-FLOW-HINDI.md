# Smart DK Classes Website v7.1

## Final Home
- Search
- Banner
- Class 9 / 10 / 11 / 12 cards
- Quick Access (PDFs, Notes, Videos, Model Papers, Vacancy Updates)
- Admin-selected Video Classes

## Class Explore Flow
Class card पर tap करने से PDF list सीधे नहीं खुलेगी।

**Class → Subject → Category → Content**

उदाहरण: Class 10 → Mathematics → Model Papers → PDF list.

## Quick Access
Quick Access जानबूझकर direct shortcut है। विद्यार्थी PDFs, Notes, Videos या Model Papers पर tap करके सभी relevant published items सीधे देख सकता है।

## Home से हटाया गया
- Latest PDFs & Study Material का अलग bundle/list Home पर नहीं है।
- Class Explore के नीचे direct mixed PDF bundle नहीं खुलेगा।

## Dynamic sync
Website Supabase `app_content` और `content_structure` पढ़ती है, इसलिए Admin App से publish/hide/move/edit किए गए Website/Both content को वेबसाइट refresh/realtime update के साथ दिखाती है।
