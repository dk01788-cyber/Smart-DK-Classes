# Smart DK Classes Website v7.2

यह v7.1 का छोटा सुधार है।

- App download button/strip वापस जोड़ दिया गया है।
- Download button Supabase `site_settings.android_apk_path` से latest APK उठाता है।
- Version text `android_app_version` से आता है।
- Quick Access, Class → Subject → Category → Content flow और selected videos में कोई बदलाव नहीं किया गया है।
- Cloudflare build output directory: `public`
