# Smart DK Classes Website v7.0 — Public App Flow

इस version में website का learning flow Public Android App के अनुसार lock किया गया है:

- Home: Search → Banner → Class Cards → Admin-selected Videos.
- Class card खोलने पर पहले Subjects आते हैं; PDF सीधे नहीं खुलता.
- Subject खोलने पर Categories आती हैं.
- Category खोलने पर उसी category का PDF/Content list आता है.
- Videos category: केवल उन्हीं Chapters के cards दिखते हैं जिनमें published video मौजूद है.
- Empty Category cards hide रहते हैं और content publish होते ही अपने-आप दिखते हैं.
- Category और Chapter cards Android app की तरह colorful palettes में हैं.
- Admin App के Supabase changes (Add/Edit/Hide/Show/Move/Publish तथा App/Website/Both) website में Realtime/polling sync से reflect होते हैं.

Final flow: Home → Class → Subject → Category → Content

नोट: APK के source/UI code में future बदलाव website code को अपने-आप rewrite नहीं कर सकता। Shared backend के content/structure changes automatic sync होते हैं; UI/code बदलाव के लिए नया website deploy चाहिए।
