# Website v6.2 - Admin Structure Sync

Website अब `app_content` के साथ `content_structure` भी पढ़ती है.

Admin App से Class Card, Subject, Category या Video Chapter Add/Edit/Hide करने पर compatible Website उसी shared backend से structure पढ़ती है. Hidden structure के अंदर का content Search/Home/Library में नहीं दिखता. Video chapter card केवल तभी दिखता है जब उस visible chapter में published video मौजूद हो.
