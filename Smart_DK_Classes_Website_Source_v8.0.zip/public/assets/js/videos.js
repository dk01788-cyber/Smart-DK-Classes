document.addEventListener("DOMContentLoaded", async () => {
  const sdk = window.smartdk;
  const grid = document.getElementById("videos-grid");
  try {
    const rows = await sdk.loadAppContent({ contentTypes:["video"] });
    grid.className = "sdkc-app-content-list";
    grid.innerHTML = rows.length ? rows.map(v => `<a class="sdkc-app-content-card" href="/video-player.html?id=${encodeURIComponent(v.id || "")}"><div class="sdkc-app-content-icon sdkc-video-icon">▶</div><div class="sdkc-app-content-copy"><span>VIDEO</span><b>${sdk.escapeHtml(v.title || "Video Class")}</b><small>${sdk.escapeHtml([v.class_name,v.subject,v.chapter_name].filter(Boolean).join(" • ") || "Smart DK Classes")}</small></div><strong class="sdkc-app-row-arrow">›</strong></a>`).join("") : '<div class="sdkc-app-empty">अभी कोई video publish नहीं है.</div>';
  } catch (_) { grid.innerHTML = '<div class="sdkc-app-empty">Videos load नहीं हो पाए.</div>'; }
  sdk.watchAppContent(() => location.reload(), 15000);
});
