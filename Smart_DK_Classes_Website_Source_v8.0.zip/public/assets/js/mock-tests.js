/* Smart DK Classes: anonymous mock tests, instant result and optional question review. */
(() => {
  'use strict';
  const target = document.getElementById('test-app');
  const sdk = window.smartdk;
  const sb = sdk?.getClient();
  const esc = sdk?.escapeHtml || (s => String(s));
  const params = new URLSearchParams(location.search);
  const state = {test:null,answers:{},position:0,result:null,filter:'all',remaining:0,timer:null,locked:false};
  const status = (s) => {target.innerHTML = `<div class="sdkc-ext-status" role="status">${esc(s)}</div>`;};
  const button = (text,act,cl='sdkc-ext-btn') => `<button class="${cl}" data-act="${act}">${esc(text)}</button>`;
  const safeId = id => /^[0-9a-f-]{36}$/i.test(String(id||''));
  const fmt = n => Number(n||0).toLocaleString('hi-IN',{maximumFractionDigits:2});
  async function call(name, args){const {data,error}=await sb.rpc(name,args);if(error)throw new Error(error.message);return data;}
  async function list(){
    status('मॉक टेस्ट लोड हो रहे हैं…');
    const {data,error}=await sb.from('sdkc_mock_tests').select('id,title,description,duration_minutes,sort_order,card_id').eq('is_published',true).order('sort_order').order('created_at',{ascending:false});
    if(error) throw error;
    let cards=[];try{const out=await sb.from('sdkc_cards').select('id,title').eq('is_published',true);cards=out.data||[];}catch(_){}
    const titleOf=id=>cards.find(x=>x.id===id)?.title||'General Mock Tests';
    const grouped={};for(const t of (data||[])){const key=titleOf(t.card_id);(grouped[key] ||= []).push(t);}
    const groups=Object.entries(grouped).map(([heading,tests])=>`<h2>${esc(heading)}</h2><div class="sdkc-ext-grid">${tests.map(t=>`<article class="sdkc-ext-card"><div class="sdkc-ext-card-title">${esc(t.title)}</div><p class="sdkc-ext-muted">${esc(t.description||'Online Practice Test')} · ${t.duration_minutes?fmt(t.duration_minutes)+' मिनट':'बिना समय सीमा'}</p><a class="sdkc-ext-btn" href="?test=${encodeURIComponent(t.id)}">Start Test</a></article>`).join('')}</div>`).join('');
    target.innerHTML=`<h1>📝 Mock Test Center</h1><p>बिना Login के टेस्ट दें और Final Submit के बाद अपना Result व Answer Review देखें।</p>${groups||'<p class="sdkc-ext-muted">अभी कोई Mock Test प्रकाशित नहीं हुआ है।</p>'}`;
  }
  function clearTimer(){if(state.timer){clearInterval(state.timer);state.timer=null;}}
  function timerString(){const s=Math.max(0,state.remaining);return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;}
  function startTimer(){
    clearTimer();if(!state.test.duration_minutes)return;
    state.remaining=state.test.duration_minutes*60;
    state.timer=setInterval(()=>{state.remaining=Math.max(0,state.remaining-1);const t=target.querySelector('#sdkc-timer');if(t)t.textContent=timerString();if(state.remaining===0){clearTimer();submit(true);}},1000);
  }
  async function start(id){
    status('प्रश्न लोड हो रहे हैं…');
    state.test=await call('sdkc_start_test',{p_test:id});state.answers={};state.position=0;state.result=null;state.locked=false;
    try{sessionStorage.removeItem(`sdkc-mock-result-${id}`);}catch(_){}
    if(!state.test.questions.length){status('इस टेस्ट में अभी प्रश्न नहीं हैं।');return;}
    showQuestion();startTimer();
  }
  function showQuestion(){
    if(!state.test || state.locked)return;
    const qs=state.test.questions,q=qs[state.position],sel=state.answers[q.id];
    target.innerHTML=`<div class="sdkc-ext-intro"><h1>${esc(state.test.title)}</h1><span class="sdkc-ext-timer" id="sdkc-timer">${state.test.duration_minutes?timerString():'No Timer'}</span></div>
      <p class="sdkc-ext-muted">प्रश्न ${state.position+1} / ${qs.length} · उत्तर दिए: ${Object.keys(state.answers).length}</p>
      <div class="sdkc-ext-card"><h2>Q${state.position+1}. ${esc(q.question_text)}</h2><div>${q.options.map((o,i)=>`<label class="sdkc-ext-choice"><input type="radio" name="sdkc-answer" value="${i}" ${sel===i?'checked':''}><span>${String.fromCharCode(65+i)}. ${esc(o)}</span></label>`).join('')}</div><div class="sdkc-ext-actions">${button('उत्तर हटाएँ','clear','sdkc-ext-btn alt')}</div></div>
      <div class="sdkc-ext-actions">${button('← Previous','prev','sdkc-ext-btn alt')}${button('Next →','next')}${button('Final Submit','final','sdkc-ext-btn warn')}</div>
      <div class="sdkc-ext-card"><p class="sdkc-ext-muted">प्रश्न चुनें:</p><div class="sdkc-ext-palette">${qs.map((x,i)=>`<button data-jump="${i}" class="${i===state.position?'active':''} ${state.answers[x.id]!==undefined?'done':''}" aria-label="Question ${i+1}">${i+1}</button>`).join('')}</div></div>`;
  }
  async function submit(auto=false){
    if(state.locked||!state.test)return;
    const unanswered=state.test.questions.length-Object.keys(state.answers).length;
    if(!auto&&!confirm(`Final Submit करें? ${unanswered} प्रश्न छोड़े गए हैं।`))return;
    state.locked=true;clearTimer();status('Result तैयार हो रहा है…');
    try{
      const data=await call('sdkc_finish_test',{p_test:state.test.id,p_answers:state.answers});
      state.result=data;state.filter='all';showResult();
      // No student account, so this machine only keeps the most recent result for reload/review.
      try{sessionStorage.setItem(`sdkc-mock-result-${state.test.id}`,JSON.stringify({title:state.test.title,result:data}));}catch(_){}
    }catch(err){state.locked=false;status(`Result नहीं मिल सका: ${err.message}. कृपया Retry करें।`);target.insertAdjacentHTML('beforeend',button('Retry Result','retry'));}
  }
  function showResult(){
    const r=state.result;if(!r)return;const percent=r.max_score>0?Math.max(0,r.score/r.max_score*100):0;
    target.innerHTML=`<h1>✅ ${esc(state.test.title)} — Result</h1><p>Final Submit सफल। नीचे अपना प्रदर्शन देखें।</p>
     <div class="sdkc-ext-grid"><div class="sdkc-ext-metric">Total<b>${fmt(r.total)}</b></div><div class="sdkc-ext-metric">Attempted<b>${fmt(r.attempted)}</b></div><div class="sdkc-ext-metric">✅ Correct<b>${fmt(r.correct)}</b></div><div class="sdkc-ext-metric">❌ Wrong<b>${fmt(r.wrong)}</b></div><div class="sdkc-ext-metric">Unattempted<b>${fmt(r.unattempted)}</b></div><div class="sdkc-ext-metric">Accuracy<b>${fmt(r.accuracy)}%</b></div><div class="sdkc-ext-metric">Score<b>${fmt(r.score)} / ${fmt(r.max_score)}</b></div><div class="sdkc-ext-metric">Marks %<b>${fmt(percent)}%</b></div></div>
     <div class="sdkc-ext-actions">${button('🔍 Review Answers','review')}${button('Retake Test','retake','sdkc-ext-btn alt')}<a class="sdkc-ext-btn alt" href="/mock-tests.html">All Tests</a></div>
     <p class="sdkc-ext-muted">Accuracy = Correct / Attempted × 100. Score में टेस्ट की Negative Marking शामिल है।</p>`;
  }
  function showReview(){
    const r=state.result; if(!r)return;
    const all=r.review||[], filtered=all.map((q,i)=>({...q,number:i+1})).filter(q=>state.filter==='all'||q.status===state.filter);
    target.innerHTML=`<h1>Answer Review</h1><p>${esc(state.test.title)} · सही ${r.correct} · गलत ${r.wrong} · छोड़े ${r.unattempted}</p>
      <div class="sdkc-ext-actions">${[['all','सभी'],['correct','✅ सही'],['wrong','❌ गलत'],['unattempted','⭕ छोड़े गए']].map(([k,t])=>button(t+' ('+(k==='all'?r.total:k==='correct'?r.correct:k==='wrong'?r.wrong:r.unattempted)+')','filter-'+k,'sdkc-ext-filter '+(state.filter===k?'active':''))).join('')}</div>
      <div role="region" aria-live="polite">${filtered.map(q=>`<article class="sdkc-ext-card sdkc-ext-${q.status==='correct'?'good':q.status==='wrong'?'bad':'skip'}"><div class="sdkc-ext-review-question">Q${q.number}. ${esc(q.question_text)}</div><p class="sdkc-ext-small"><strong>स्थिति:</strong> ${q.status==='correct'?'✅ सही':q.status==='wrong'?'❌ गलत':'⭕ छोड़ा हुआ'}</p><div class="sdkc-ext-answer"><strong>आपका उत्तर:</strong> ${q.selected_index==null?'उत्तर नहीं दिया':esc(String.fromCharCode(65+q.selected_index)+'. '+q.options[q.selected_index])}</div>${r.show_answers?`<div class="sdkc-ext-answer"><strong>सही उत्तर:</strong> ${esc(String.fromCharCode(65+q.correct_index)+'. '+q.options[q.correct_index])}</div>${q.explanation?`<p><strong>Explanation:</strong> ${esc(q.explanation)}</p>`:''}`:'<p class="sdkc-ext-muted">इस टेस्ट में Admin ने Answer Key छिपाई है।</p>'}</article>`).join('')||'<div class="sdkc-ext-status">इस फिल्टर में कोई प्रश्न नहीं है।</div>'}</div>
     <div class="sdkc-ext-actions">${button('← Result पर जाएँ','result','sdkc-ext-btn alt')}${button('फिर से Test दें','retake','sdkc-ext-btn alt')}</div>`;
  }
  target.addEventListener('change',e=>{if(e.target.matches('input[name="sdkc-answer"]')&&!state.locked){state.answers[state.test.questions[state.position].id]=Number(e.target.value);showQuestion();}});
  target.addEventListener('click',e=>{
    const jump=e.target.closest('[data-jump]');if(jump&&!state.locked){state.position=Number(jump.dataset.jump);showQuestion();return;}
    const b=e.target.closest('[data-act]');if(!b)return;
    const act=b.dataset.act;
    if(act==='next'){state.position=Math.min(state.position+1,state.test.questions.length-1);showQuestion();}
    else if(act==='prev'){state.position=Math.max(0,state.position-1);showQuestion();}
    else if(act==='clear'){delete state.answers[state.test.questions[state.position].id];showQuestion();}
    else if(act==='final')submit(false);
    else if(act==='retry')submit(true);
    else if(act==='review'){state.filter='all';showReview();}
    else if(act==='result')showResult();
    else if(act.startsWith('filter-')){state.filter=act.slice(7);showReview();}
    else if(act==='retake'){if(confirm('नया Test शुरू करें?'))start(state.test.id).catch(e=>status(e.message));}
  });
  if(!sb){status('Supabase connection उपलब्ध नहीं है।');return;}
  const testId=params.get('test');if(testId){
    if(!safeId(testId)){status('अमान्य Test ID।');return;}
    let saved=null;try{saved=JSON.parse(sessionStorage.getItem(`sdkc-mock-result-${testId}`)||'null');}catch(_){}
    if(saved?.result && saved?.title){state.test={id:testId,title:saved.title};state.result=saved.result;state.locked=true;showResult();}
    else start(testId).catch(e=>status('Test खोलने में समस्या: '+e.message));
  }else list().catch(e=>status('Mock Tests नहीं मिल सके: '+e.message));
})();
