document.addEventListener("DOMContentLoaded", async () => {
  const sdk = window.smartdk;
  const id = new URLSearchParams(location.search).get("id") || "";
  const titleEl = document.getElementById("video-title");
  const metaEl = document.getElementById("video-meta");
  const stage = document.getElementById("video-stage");
  const details = document.getElementById("video-details");
  document.getElementById("video-back")?.addEventListener("click", () => history.length > 1 ? history.back() : location.assign("/library.html"));

  const extractYouTubeId = value => {
    const raw = String(value || "").trim();
    if (!raw) return "";
    try {
      const u = new URL(raw);
      if (u.hostname.includes("youtu.be")) return u.pathname.split("/").filter(Boolean)[0] || "";
      if (u.hostname.includes("youtube.com")) {
        if (u.pathname.startsWith("/shorts/") || u.pathname.startsWith("/embed/")) return u.pathname.split("/").filter(Boolean)[1] || "";
        return u.searchParams.get("v") || "";
      }
    } catch (_) {}
    return /^[\w-]{6,20}$/.test(raw) ? raw : "";
  };

  try {
    const rows = await sdk.loadAppContent({ contentTypes:["video"] });
    const item = rows.find(x => String(x.id || "") === String(id));
    if (!item) throw new Error("Video not found");
    const youtubeUrl = item.youtube_url || item.external_url || "";
    const ytId = extractYouTubeId(youtubeUrl);
    titleEl.textContent = item.title || "Video Class";
    metaEl.textContent = [item.class_name,item.subject,item.chapter_name].filter(Boolean).join(" • ") || "Smart DK Classes";
    document.title = `${item.title || "Video Class"} | Smart DK Classes`;

    if (ytId) {
      stage.innerHTML = `<div class="sdkc-video-embed"><iframe src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(ytId)}?rel=0&modestbranding=1" title="${sdk.escapeHtml(item.title || "Smart DK Classes Video")}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>`;
    } else if (youtubeUrl) {
      stage.innerHTML = '<div class="sdkc-app-empty">यह video embedded player में उपलब्ध नहीं है. नीचे View on YouTube दबाएँ.</div>';
    } else {
      stage.innerHTML = '<div class="sdkc-app-empty">Video link उपलब्ध नहीं है.</div>';
    }
    details.innerHTML = `<div class="sdkc-video-info-card"><b>${sdk.escapeHtml(item.title || "Video Class")}</b><p>${sdk.escapeHtml(item.description || "Smart DK Classes video lesson")}</p>${youtubeUrl ? `<a class="sdkc-primary-button" href="${sdk.escapeHtml(youtubeUrl)}" target="_blank" rel="noopener">▶ View on YouTube</a>` : ""}</div>`;
  } catch (_) {
    stage.innerHTML = '<div class="sdkc-app-empty">Video load नहीं हो पाया.</div>';
  }
});
