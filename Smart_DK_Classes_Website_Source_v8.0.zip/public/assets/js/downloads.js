document.addEventListener("DOMContentLoaded", async () => {
  const sdk = window.smartdk;
  const list = document.getElementById("download-history");
  const clear = document.getElementById("clear-download-history");
  const apkCard = document.getElementById("apk-download-card");
  const KEY = "sdkcDownloadHistoryV1";
  const read = () => { try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch (_) { return []; } };
  const render = () => {
    const rows = read();
    list.innerHTML = rows.length ? rows.map(x => `<a class="sdkc-app-content-card" href="${sdk.escapeHtml(x.url)}" target="_blank" rel="noopener"><div class="sdkc-app-content-icon">PDF</div><div class="sdkc-app-content-copy"><span>RECENT DOWNLOAD</span><b>${sdk.escapeHtml(x.title || "PDF")}</b><small>${new Date(x.at || Date.now()).toLocaleString()}</small></div><strong class="sdkc-app-row-arrow">↓</strong></a>`).join("") : '<div class="sdkc-app-empty">No recent downloads yet.</div>';
  };
  clear?.addEventListener("click", () => { localStorage.removeItem(KEY); render(); });
  render();

  try {
    const cfg = window.SMART_DK_CONFIG || {};
    const sb = sdk.getClient();
    if (sb) {
      const {data} = await sb.from("site_settings").select("android_apk_path,android_app_version").eq("id",1).maybeSingle();
      const path = String(data?.android_apk_path || "").replace(/^\/+/,"");
      const base = String(cfg.supabaseUrl || "").replace(/\/$/,"");
      if (path && base) {
        const url = `${base}/storage/v1/object/public/app-downloads/${path.split("/").map(encodeURIComponent).join("/")}`;
        apkCard.innerHTML = `<div class="sdkc-apk-card"><div><span>📱</span><div><b>Smart DK Classes Android App</b><small>${data?.android_app_version ? `Version ${sdk.escapeHtml(data.android_app_version)} • ` : ""}Official APK</small></div></div><a href="${sdk.escapeHtml(url)}" download>Download APK</a></div>`;
      }
    }
  } catch (_) {}
});
