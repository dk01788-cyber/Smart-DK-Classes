document.addEventListener("DOMContentLoaded", async () => {
  const btn = document.getElementById("home-apk-download");
  const ver = document.getElementById("home-apk-version");
  if (!btn) return;
  try {
    const sdk = window.smartdk;
    if (!sdk?.configured?.()) return;
    const sb = sdk.getClient();
    const { data, error } = await sb.from("site_settings")
      .select("android_apk_path,android_app_version")
      .eq("id", 1)
      .maybeSingle();
    if (error || !data) return;
    const path = String(data.android_apk_path || "").replace(/^\/+/, "");
    const base = String(window.SMART_DK_CONFIG?.supabaseUrl || "").replace(/\/$/, "");
    if (path && base) {
      btn.href = `${base}/storage/v1/object/public/app-downloads/${path.split("/").map(encodeURIComponent).join("/")}`;
    }
    if (ver && data.android_app_version) {
      ver.textContent = `Latest version ${data.android_app_version} • Android APK सीधे डाउनलोड करें`;
    }
  } catch (_) {
    // Keep the working v1.3.1 fallback link already present in HTML.
  }
});
