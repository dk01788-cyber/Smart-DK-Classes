document.addEventListener("DOMContentLoaded", async () => {
  const sdk = window.smartdk;
  const view = document.getElementById("library-view");
  const crumbs = document.getElementById("library-breadcrumb");
  const searchForm = document.getElementById("library-search-form");
  const searchInput = document.getElementById("library-search");
  const params = new URLSearchParams(location.search);
  const classParamRaw = params.get("class") || "";
  const subjectParam = params.get("subject") || "";
  const categoryParam = params.get("category") || "";
  const chapterParam = params.get("chapter") || "";
  const queryParam = params.get("q") || "";
  const quickParam = params.get("quick") || "";
  let rows = [], structure = [];

  const same = (a,b) => String(a||"").trim().toLowerCase() === String(b||"").trim().toLowerCase();
  const normClassName = value => {
    const raw=String(value||"").trim();
    if(/^\d+$/.test(raw)) return `Class ${raw}`;
    return raw;
  };
  const classNameParam = normClassName(classParamRaw);
  const normSubject = value => {
    const raw = String(value || "").trim();
    const key = raw.toLowerCase().replace(/\s+/g," ");
    const map = {math:"Mathematics", maths:"Mathematics", mathematics:"Mathematics", science:"Science", physics:"Physics", chemistry:"Chemistry", biology:"Biology", english:"English", hindi:"Hindi", "social science":"Social Science", "social studies":"Social Science", sst:"Social Science"};
    return map[key] || raw;
  };
  const normCategory = value => {
    const raw = String(value || "").trim();
    const key = raw.toLowerCase().replace(/\s+/g," ");
    const aliases = {
      video:"Videos", videos:"Videos", "chapter videos":"Videos", "chapter-wise videos":"Videos", "chapter wise videos":"Videos",
      handwritten:"Handwritten Notes", "handwritten note":"Handwritten Notes", "handwritten notes":"Handwritten Notes",
      note:"Notes", notes:"Notes", "question bank":"Question Bank", "question paper":"Question Bank", "question papers":"Question Bank",
      "model paper":"Model Papers", "model papers":"Model Papers", "previous year paper":"Previous Year Papers", "previous year papers":"Previous Year Papers", pyq:"Previous Year Papers", pyqs:"Previous Year Papers",
      "important question":"Important Questions", "important questions":"Important Questions", formula:"Formula / Revision Sheet", "formula sheet":"Formula / Revision Sheet", revision:"Formula / Revision Sheet", "revision sheet":"Formula / Revision Sheet",
      "practice set":"Practice Sets / Worksheets", "practice sets":"Practice Sets / Worksheets", worksheet:"Practice Sets / Worksheets", worksheets:"Practice Sets / Worksheets"
    };
    return aliases[key] || raw;
  };
  const displayCategory = item => {
    if (item.category || item.content_category) return normCategory(item.category || item.content_category);
    const t = String(item.content_type || "").toLowerCase();
    if (t === "video") return "Videos";
    if (t === "handwritten_note") return "Handwritten Notes";
    if (t === "model_paper") return "Model Papers";
    if (["question_bank","question_paper"].includes(t)) return "Question Bank";
    if (t === "previous_year_paper") return "Previous Year Papers";
    if (t === "important_question") return "Important Questions";
    if (["formula_sheet","revision_sheet"].includes(t)) return "Formula / Revision Sheet";
    if (["practice_set","worksheet"].includes(t)) return "Practice Sets / Worksheets";
    if (["note","pdf"].includes(t)) {
      const title = String(item.title || "").toLowerCase();
      if (title.includes("handwritten") || title.includes("हस्तलिखित")) return "Handwritten Notes";
      if (title.includes("formula") || title.includes("सूत्र") || title.includes("revision")) return "Formula / Revision Sheet";
      return "Notes";
    }
    return "Study Material";
  };
  const searchable = item => [item.title,item.description,item.class_name,item.subject,displayCategory(item),item.chapter_name,item.content_type].filter(Boolean).join(" ").toLowerCase();
  const orderedUnique = values => {
    const out=[];
    for(const v of values){const x=String(v||"").trim();if(x&&!out.some(y=>same(x,y)))out.push(x);}
    return out;
  };
  const managed = () => structure.length > 0;
  const ofType = type => structure.filter(x=>x.item_type===type);
  const classRows = () => ofType("class");
  const subjectRows = cls => ofType("subject").filter(x=>same(x.class_name,cls));
  const categoryRows = (cls,sub) => ofType("category").filter(x=>same(x.class_name,cls)&&same(normSubject(x.subject),normSubject(sub)));
  const chapterRows = (cls,sub) => ofType("chapter").filter(x=>same(x.class_name,cls)&&same(normSubject(x.subject),normSubject(sub)));
  const videoCategoryName = (cls,sub) => categoryRows(cls,sub).find(x=>String(x.system_key||"").toLowerCase()==="videos")?.name || "Videos";
  const isVideoStructureCategory = row => String(row?.system_key||"").toLowerCase()==="videos" || same(normCategory(row?.name),"Videos");
  const hasPublishedContentForCategory = (cls,sub,rowOrName) => {
    const row = typeof rowOrName === "object" ? rowOrName : categoryRows(cls,sub).find(x=>same(x.name,rowOrName));
    const label = typeof rowOrName === "object" ? String(rowOrName?.name||"") : String(rowOrName||"");
    const videoShelf = row ? isVideoStructureCategory(row) : same(normCategory(label),"Videos");
    return rows.some(item => {
      if(!same(item.class_name,cls) || !same(normSubject(item.subject),normSubject(sub))) return false;
      if(String(item.content_type||"").toLowerCase()==="vacancy") return false;
      if(videoShelf) return String(item.content_type||"").toLowerCase()==="video";
      return same(normCategory(displayCategory(item)),normCategory(label));
    });
  };

  function pathVisible(item){
    if(item.sdkc_direct || !managed() || String(item.content_type||"").toLowerCase()==="vacancy") return true;
    if(!classRows().some(x=>same(x.name,item.class_name))) return false;
    if(!subjectRows(item.class_name).some(x=>same(normSubject(x.name),normSubject(item.subject)))) return false;
    const itemType=String(item.content_type||"").toLowerCase();
    const itemCategories=categoryRows(item.class_name,item.subject);
    const categoryVisible=itemType==="video"
      ? itemCategories.some(x=>String(x.system_key||"").toLowerCase()==="videos" || same(normCategory(x.name),"Videos"))
      : itemCategories.some(x=>same(normCategory(x.name),normCategory(displayCategory(item))));
    if(!categoryVisible) return false;
    if(itemType==="video" && String(item.chapter_name||"").trim()){
      if(!chapterRows(item.class_name,item.subject).some(x=>same(x.name,item.chapter_name))) return false;
    }
    return true;
  }

  function setBreadcrumb(parts) {
    const links = [{label:"Classes", href:"/library.html"}, ...parts];
    crumbs.innerHTML = links.map((p,i) => i === links.length - 1 ? `<span>${sdk.escapeHtml(p.label)}</span>` : `<a href="${sdk.escapeHtml(p.href)}">${sdk.escapeHtml(p.label)}</a><i>›</i>`).join("");
  }
  function sectionTitle(title, subtitle = "") {
    return `<div class="sdkc-app-section-title sdkc-browser-title"><div><h2>${sdk.escapeHtml(title)}</h2>${subtitle ? `<p>${sdk.escapeHtml(subtitle)}</p>` : ""}</div></div>`;
  }
  const structureStyle = row => {
    if(!row)return '';
    const mode=row.sdkc_background_mode||'solid';
    const color=/^#[a-f0-9]{6}$/i.test(row.sdkc_background_color||'')?row.sdkc_background_color:'#2563eb';
    const second=/^#[a-f0-9]{6}$/i.test(row.sdkc_gradient_color||'')?row.sdkc_gradient_color:'#0f766e';
    const url=/^https:\/\//.test(row.sdkc_background_image||'')?String(row.sdkc_background_image).replace(/[\"'<>]/g,''):'';
    if(mode==='image'&&url)return `background:linear-gradient(#0007,#0007),url('${url}') center/cover;color:#fff`;
    if(mode==='gradient')return `background:linear-gradient(135deg,${color},${second});color:#fff`;
    return row.sdkc_background_color?`background:${color};color:#fff`:'';
  };
  const rowFor=(kind,cls,sub,cat,name)=>structure.find(x=>x.item_type===kind&&same(x.name,name)&&(!cls||same(x.class_name,cls))&&(!sub||same(normSubject(x.subject),normSubject(sub)))&&(!cat||same(x.category,cat)));
  const classHref = name => `/library.html?class=${encodeURIComponent(name)}`;
  const classNumber = name => (String(name||"").match(/\d+/)||["•"])[0];

  function classGrid() {
    setBreadcrumb([{label:"Choose Class",href:"/library.html"}]);
    let classes = managed() ? classRows().map(x=>x.name) : ["Class 9","Class 10","Class 11","Class 12"];
    classes=orderedUnique(classes);
    view.innerHTML = sectionTitle("Choose Class") + (classes.length ? `<div class="sdkc-app-class-grid">${classes.map((name,i)=>`<a class="sdkc-app-class-card class-${classNumber(name)}" style="${structureStyle(rowFor('class',null,null,null,name))}" href="${classHref(name)}"><span>${sdk.escapeHtml(classNumber(name))}</span><div><b>${sdk.escapeHtml(name)}</b><small>Explore Subjects</small></div><strong>›</strong></a>`).join("")}</div>` : '<div class="sdkc-app-empty">No class is currently visible.</div>');
  }

  function subjectGrid() {
    const cls=classNameParam;
    let subjects;
    if(managed()) subjects=subjectRows(cls).map(x=>normSubject(x.name));
    else subjects=rows.filter(x=>same(x.class_name,cls)&&String(x.content_type||"").toLowerCase()!=="vacancy").map(x=>normSubject(x.subject));
    subjects=orderedUnique(subjects);
    setBreadcrumb([{label:cls,href:classHref(cls)}]);
    view.innerHTML = sectionTitle("Subjects", cls) + (subjects.length ? `<div class="sdkc-app-tile-grid">${subjects.map((s,i)=>`<a class="sdkc-app-subject-card subject-${i%4}" style="${structureStyle(rowFor('subject',cls,null,null,s))}" href="/library.html?class=${encodeURIComponent(cls)}&subject=${encodeURIComponent(s)}"><span>${["∑","⚗","A","क"][i%4]}</span><b>${sdk.escapeHtml(s)}</b><small>Explore Categories</small></a>`).join("")}</div>` : '<div class="sdkc-app-empty">इस class के लिए अभी कोई visible subject नहीं है.</div>');
  }

  function categoryGrid() {
    const cls=classNameParam, sub=normSubject(subjectParam);
    let cats;
    if(managed()) {
      // Match the Android app: an empty category card is never shown.
      cats=categoryRows(cls,sub).filter(row=>hasPublishedContentForCategory(cls,sub,row)).map(x=>x.name);
    } else {
      cats=rows.filter(x=>same(x.class_name,cls)&&same(normSubject(x.subject),sub)&&String(x.content_type||"").toLowerCase()!=="vacancy").map(displayCategory);
    }
    cats=orderedUnique(cats);
    setBreadcrumb([{label:cls,href:classHref(cls)},{label:sub,href:`/library.html?class=${encodeURIComponent(cls)}&subject=${encodeURIComponent(sub)}`}]);
    const icons={"Handwritten Notes":"✍","Notes":"▤","Question Bank":"?","Model Papers":"▣","Previous Year Papers":"★","Important Questions":"!","Formula / Revision Sheet":"ƒ","Practice Sets / Worksheets":"✓"};
    const categoryClass=(c,i)=>{const k=String(c||"").trim().toLowerCase();const map={"handwritten notes":"cat-handwritten",notes:"cat-notes","question bank":"cat-question-bank","model papers":"cat-model","previous year papers":"cat-previous","important questions":"cat-important","formula / revision sheet":"cat-formula","practice sets / worksheets":"cat-practice"};return (same(c,videoCategoryName(cls,sub))?"cat-videos":(map[k]||`cat-auto-${i%6}`));};
    view.innerHTML = sectionTitle(sub, `${cls} • Choose Category`) + (cats.length ? `<div class="sdkc-app-category-grid">${cats.map((c,i)=>{const isVideo=same(c,videoCategoryName(cls,sub));return `<a class="sdkc-app-category-card ${categoryClass(c,i)}" style="${structureStyle(rowFor('category',cls,sub,null,c))}" href="/library.html?class=${encodeURIComponent(cls)}&subject=${encodeURIComponent(sub)}&category=${encodeURIComponent(c)}"><span>${isVideo?"▶":(icons[c]||"▤")}</span><div><b>${sdk.escapeHtml(c)}</b><small>${isVideo?"Chapter-wise Videos":"Open Content"}</small></div><strong>›</strong></a>`}).join("")}</div>` : '<div class="sdkc-app-empty">इस subject में अभी कोई visible category नहीं है.</div>');
  }

  function contentUrl(item){if(item.file_path)return sdk.publicContentUrl(item.file_path);return item.external_url||item.youtube_url||"";}
  function contentCard(item){
    const type=String(item.content_type||"").toLowerCase(),isVideo=type==="video",isFile=Boolean(item.file_path),category=displayCategory(item),meta=[item.class_name,normSubject(item.subject),item.chapter_name||category].filter(Boolean).join(" • "),href=contentUrl(item);
    if(isVideo)return `<a class="sdkc-app-content-card" href="/video-player.html?id=${encodeURIComponent(item.id||"")}"><div class="sdkc-app-content-icon sdkc-video-icon">▶</div><div class="sdkc-app-content-copy"><span>VIDEO</span><b>${sdk.escapeHtml(item.title||"Video")}</b><small>${sdk.escapeHtml(meta)}</small></div><strong class="sdkc-app-row-arrow">›</strong></a>`;
    const viewer=isFile&&href?`/pdf-viewer.html?url=${encodeURIComponent(href)}&title=${encodeURIComponent(item.title||"Smart DK Classes PDF")}`:href||"#";
    return `<article class="sdkc-app-content-card"><div class="sdkc-app-content-icon">PDF</div><div class="sdkc-app-content-copy"><span>${sdk.escapeHtml(category.toUpperCase())}</span><b>${sdk.escapeHtml(item.title||"Study Material")}</b><small>${sdk.escapeHtml(meta)}</small></div><div class="sdkc-app-row-actions">${viewer!=="#"?`<a href="${sdk.escapeHtml(viewer)}">Open</a>`:""}${isFile&&href?`<a class="sdkc-download-track" data-download-title="${sdk.escapeHtml(item.title||"PDF")}" data-download-url="${sdk.escapeHtml(href)}" href="${sdk.escapeHtml(href)}" target="_blank" rel="noopener" download>Download</a>`:""}</div></article>`;
  }

  function chapterView(videos,cls,sub,cat){
    let chapters=orderedUnique(videos.map(v=>v.chapter_name));
    if(managed()){
      const allowed=chapterRows(cls,sub).map(x=>x.name);
      chapters=allowed.filter(ch=>videos.some(v=>same(v.chapter_name,ch)));
    }
    setBreadcrumb([{label:cls,href:classHref(cls)},{label:sub,href:`/library.html?class=${encodeURIComponent(cls)}&subject=${encodeURIComponent(sub)}`},{label:cat,href:`/library.html?class=${encodeURIComponent(cls)}&subject=${encodeURIComponent(sub)}&category=${encodeURIComponent(cat)}`}]);
    if(chapterParam){
      const chapterVideos=videos.filter(v=>same(v.chapter_name,chapterParam));
      view.innerHTML=sectionTitle(chapterParam,`${cls} • ${sub}`)+`<div class="sdkc-app-content-list">${chapterVideos.map(contentCard).join("")}</div>`;
      return;
    }
    let html=sectionTitle("Chapter-wise Videos",`${cls} • ${sub}`);
    if(chapters.length)html+=`<div class="sdkc-app-category-grid">${chapters.map((ch,i)=>{const count=videos.filter(v=>same(v.chapter_name,ch)).length;return `<a class="sdkc-app-category-card sdkc-chapter-${i%5}" style="${structureStyle(rowFor('chapter',cls,sub,cat,ch))}" href="/library.html?class=${encodeURIComponent(cls)}&subject=${encodeURIComponent(sub)}&category=${encodeURIComponent(cat)}&chapter=${encodeURIComponent(ch)}"><span>▶</span><div><b>${sdk.escapeHtml(ch)}</b><small>${count} video${count===1?"":"s"}</small></div><strong>›</strong></a>`}).join("")}</div>`;
    view.innerHTML=html;
  }

  function categoryContent(){
    const cls=classNameParam,sub=normSubject(subjectParam),cat=categoryParam;
    const catRow=categoryRows(cls,sub).find(x=>same(x.name,cat));
    const isVideo=(catRow && isVideoStructureCategory(catRow)) || same(cat,videoCategoryName(cls,sub)) || same(normCategory(cat),"Videos");
    const filtered=rows.filter(x=>{
      if(!same(x.class_name,cls)||!same(normSubject(x.subject),sub)) return false;
      if(isVideo) return String(x.content_type||"").toLowerCase()==="video";
      return same(normCategory(displayCategory(x)),normCategory(cat));
    });
    if(isVideo)return chapterView(filtered,cls,sub,cat);
    setBreadcrumb([{label:cls,href:classHref(cls)},{label:sub,href:`/library.html?class=${encodeURIComponent(cls)}&subject=${encodeURIComponent(sub)}`},{label:cat,href:`/library.html?class=${encodeURIComponent(cls)}&subject=${encodeURIComponent(sub)}&category=${encodeURIComponent(cat)}`}]);
    view.innerHTML=sectionTitle(cat,`${cls} • ${sub}`)+`<div class="sdkc-app-content-list">${filtered.length?filtered.map(contentCard).join(""):'<div class="sdkc-app-empty">इस category में अभी content publish नहीं है.</div>'}</div>`;
  }

  function quickView(kind){
    const key=String(kind||"").trim().toLowerCase();
    let title="Quick Access", subtitle="", found=[];
    if(key==="pdfs") {
      title="PDFs"; subtitle="All available study material";
      found=rows.filter(x=>String(x.content_type||"").toLowerCase()!=="video" && String(x.content_type||"").toLowerCase()!=="vacancy" && (x.file_path||x.external_url));
    } else if(key==="notes") {
      title="Notes"; subtitle="Handwritten & standard notes";
      found=rows.filter(x=>["Notes","Handwritten Notes"].some(c=>same(normCategory(displayCategory(x)),c)));
    } else if(key==="videos") {
      title="Videos"; subtitle="All published video classes";
      found=rows.filter(x=>String(x.content_type||"").toLowerCase()==="video");
    } else if(key==="model-papers") {
      title="Model Papers"; subtitle="Board exam practice material";
      found=rows.filter(x=>same(normCategory(displayCategory(x)),"Model Papers") || String(x.content_type||"").toLowerCase()==="model_paper");
    } else {
      classGrid(); return;
    }
    setBreadcrumb([{label:"Quick Access",href:`/library.html?quick=${encodeURIComponent(key)}`}]);
    view.innerHTML=sectionTitle(title,subtitle)+`<div class="sdkc-app-content-list">${found.length?found.map(contentCard).join(""):'<div class="sdkc-app-empty">अभी इस Quick Access section में कोई published content नहीं है.</div>'}</div>`;
  }

  function searchView(q){
    const query=q.trim().toLowerCase();setBreadcrumb([{label:"Search",href:`/library.html?q=${encodeURIComponent(q)}`}]);searchInput.value=q;
    if(!query){view.innerHTML=sectionTitle("Search")+'<div class="sdkc-app-empty">Title, subject, chapter या category लिखकर search करें.</div>';return;}
    const found=rows.filter(x=>searchable(x).includes(query));
    view.innerHTML=sectionTitle("Search Results",`${found.length} result${found.length===1?"":"s"}`)+`<div class="sdkc-app-content-list">${found.length?found.map(contentCard).join(""):'<div class="sdkc-app-empty">कोई matching content नहीं मिला.</div>'}</div>`;
  }

  searchForm?.addEventListener("submit",e=>{e.preventDefault();const q=searchInput.value.trim();location.href=q?`/library.html?q=${encodeURIComponent(q)}`:"/library.html?search=1";});

  try {[rows,structure]=await Promise.all([sdk.loadAppContent(),sdk.loadContentStructure()]);}catch(_){rows=[];structure=[];}
  try {
    const client=sdk.getClient();
    if(client){const {data:extra,error}=await client.from('sdkc_materials').select('*').eq('is_published',true).order('sort_order');
      if(!error)rows.push(...(extra||[]).map(m=>({...m,class_name:m.academic_class||'',subject:m.academic_subject||'',category:m.academic_category||'',chapter_name:m.academic_chapter||'',content_type:m.item_type,sdkc_direct:true})));
    }
  }catch(_){}
  rows=rows.filter(pathVisible);

  if(quickParam)quickView(quickParam);
  else if(queryParam||params.has("search"))searchView(queryParam);
  else if(!classNameParam)classGrid();
  else if(!subjectParam)subjectGrid();
  else if(!categoryParam)categoryGrid();
  else categoryContent();

  sdk.watchAppContent(()=>location.reload(),15000);
  sdk.watchContentStructure(()=>location.reload(),15000);
});
