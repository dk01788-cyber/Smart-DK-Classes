# Website v7.3 — APK Button Guaranteed

- Home page par APK download strip ko permanent HTML section banaya gaya hai.
- Supabase site_settings load fail ho tab bhi current v1.3.1 APK ka fallback download button visible rahega.
- Supabase se latest android_apk_path/android_app_version milte hi link/version auto-update hoga.
- Old dynamic-only strip logic hatayi gayi hai taaki duplicate na bane.
- CSS/JS par v=7.3 cache-busting aur _headers no-cache add kiya gaya hai.
- v7.1 ka Quick Access aur Class → Subject → Category → Content flow unchanged hai.
