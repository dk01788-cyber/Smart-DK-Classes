(async function () {
  const cfg = window.SMART_DK_CONFIG || {};
  const esc = value => String(value ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;");
  let settings = { ...cfg };
  let appSettings = {};
  try {
    if (window.smartdk?.configured()) {
      const sb = window.smartdk.getClient();
      const [{data:st},{data:app}] = await Promise.all([
        sb.from("site_settings").select("*").eq("id",1).maybeSingle(),
        sb.from("app_settings").select("*").eq("id",1).maybeSingle()
      ]);
      if (st) settings = {...settings,...st};
      if (app) appSettings = app;
    }
  } catch (_) {}

  const header = document.getElementById("app-header");
  const footer = document.getElementById("app-footer");
  const path = location.pathname;
  const isHome = path === "/" || path.endsWith("/index.html");
  const isLibrary = path.includes("library.html");
  const isDownloads = path.includes("downloads.html");
  const supportEmail = cfg.supportEmail || settings.support_email || settings.supportEmail || "smartdkclasses.help@gmail.com";
  const blogUrl = appSettings.blogger_url || "https://smartdkclasses.blogspot.com/";
  const youtubeUrl = appSettings.youtube_channel_url || "https://www.youtube.com/@smartdkclasses";

  const nav = [
    ["/", "⌂", "Home", isHome],
    ["/library.html", "▣", "Classes", isLibrary && !new URLSearchParams(location.search).has("q") && !new URLSearchParams(location.search).has("search")],
    ["/library.html?search=1", "⌕", "Search", isLibrary && (new URLSearchParams(location.search).has("q") || new URLSearchParams(location.search).has("search"))],
    ["/downloads.html", "⇩", "Downloads", isDownloads]
  ];

  if (header) {
    header.innerHTML = `<header class="sdkc-app-topbar"><div class="sdkc-app-shell sdkc-topbar-inner">
      <a class="sdkc-app-brand" href="/"><img src="/assets/img/logo.png" alt="Smart DK Classes"><span><b>Smart DK Classes</b><small>Learn • Practice • Grow</small></span></a>
      <nav class="sdkc-desktop-nav">${nav.map(([href,icon,label,active])=>`<a class="${active?"active":""}" href="${href}"><span>${icon}</span>${label}</a>`).join("")}<a href="${esc(blogUrl)}" target="_blank" rel="noopener"><span>✎</span>Blog</a></nav>
    </div></header>`;
  }

  if (footer) {
    footer.innerHTML = `<footer class="sdkc-app-footer"><div class="sdkc-app-shell sdkc-footer-grid">
      <div><b>Smart DK Classes</b><p>Class 9, 10, 11 और 12 के लिए खुला learning platform.</p></div>
      <div><b>Learning</b><a href="/library.html">Classes</a><a href="/videos.html">All Videos</a><a href="/vacancies.html">Vacancy Updates</a><a href="/guides.html">Study Guides</a></div>
      <div><b>Information</b><a href="/about.html">About</a><a href="/contact.html">Contact</a><a href="/privacy-policy.html">Privacy Policy</a><a href="/terms.html">Terms</a></div>
      <div><b>Connect</b><a href="mailto:${esc(supportEmail)}">${esc(supportEmail)}</a><a href="${esc(youtubeUrl)}" target="_blank" rel="noopener">YouTube</a><a href="${esc(blogUrl)}" target="_blank" rel="noopener">Blog</a></div>
    </div><div class="sdkc-app-shell sdkc-footer-copy">© ${new Date().getFullYear()} Smart DK Classes</div></footer>
    <nav class="sdkc-mobile-bottom-nav" aria-label="Main navigation">${nav.map(([href,icon,label,active])=>`<a class="${active?"active":""}" href="${href}"><span>${icon}</span><small>${label}</small></a>`).join("")}</nav>`;
  }

  // Record website PDF downloads locally so Downloads mirrors the public app's convenience section.
  document.addEventListener("click", e => {
    const link = e.target.closest?.(".sdkc-download-track");
    if (!link) return;
    const KEY = "sdkcDownloadHistoryV1";
    try {
      const rows = JSON.parse(localStorage.getItem(KEY) || "[]");
      const url = link.dataset.downloadUrl || link.href || "";
      const title = link.dataset.downloadTitle || "Smart DK Classes PDF";
      const next = [{title,url,at:Date.now()}, ...rows.filter(x => x.url !== url)].slice(0,30);
      localStorage.setItem(KEY, JSON.stringify(next));
    } catch (_) {}
  });
})();
