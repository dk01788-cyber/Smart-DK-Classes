document.addEventListener("DOMContentLoaded", async () => {
  const sdk = window.smartdk;
  const videoEl = document.getElementById("home-videos");
  const classEl = document.getElementById("home-class-grid");
  const form = document.getElementById("home-search-form");
  const input = document.getElementById("home-search");

  form?.addEventListener("submit", (e) => {
    e.preventDefault();
    const q = input?.value?.trim() || "";
    location.href = q ? `/library.html?q=${encodeURIComponent(q)}` : "/library.html?search=1";
  });

  const same = (a,b) => String(a||"").trim().toLowerCase() === String(b||"").trim().toLowerCase();
  const orderedUnique = values => {
    const out=[];
    for(const v of values){const x=String(v||"").trim(); if(x && !out.some(y=>same(x,y))) out.push(x);}
    return out;
  };
  const classNo = name => (String(name||"").match(/\d+/)||[""])[0];
  const classHref = name => `/library.html?class=${encodeURIComponent(name)}`;

  function renderClasses(structure){
    let classes = (structure||[]).filter(x=>x.item_type === "class").map(x=>x.name);
    classes = orderedUnique(classes);
    if(!classes.length) classes=["Class 9","Class 10","Class 11","Class 12"];
    if(!classEl) return;
    classEl.innerHTML = classes.map((name,i)=>{
      const n=classNo(name)||"•";
      return `<a class="sdkc-app-class-card class-${n||i}" href="${classHref(name)}"><span>${sdk.escapeHtml(n)}</span><div><b>${sdk.escapeHtml(name)}</b><small>Explore Subjects</small></div><strong>›</strong></a>`;
    }).join("") || '<div class="sdkc-app-empty">No class is currently visible.</div>';
  }

  function videoHref(item) {
    return `/video-player.html?id=${encodeURIComponent(item.id || "")}`;
  }

  function videoCard(item) {
    const meta = [item.class_name, item.subject, item.chapter_name].filter(Boolean).join(" • ") || "Smart DK Classes";
    const thumb = item.thumbnail_url || "";
    return `<a class="sdkc-app-content-card sdkc-app-video-row" href="${videoHref(item)}">
      <div class="sdkc-app-content-icon sdkc-video-icon">${thumb ? `<img src="${sdk.escapeHtml(thumb)}" alt="">` : "▶"}</div>
      <div class="sdkc-app-content-copy"><span>VIDEO CLASS</span><b>${sdk.escapeHtml(item.title || "Video Class")}</b><small>${sdk.escapeHtml(meta)}</small></div>
      <strong class="sdkc-app-row-arrow">›</strong>
    </a>`;
  }

  function normSubject(value){
    const raw=String(value||"").trim(), key=raw.toLowerCase().replace(/\s+/g," ");
    const map={math:"Mathematics",maths:"Mathematics",mathematics:"Mathematics",sst:"Social Science","social studies":"Social Science"};
    return map[key]||raw;
  }
  function normCategory(value){
    const raw=String(value||"").trim(), key=raw.toLowerCase().replace(/\s+/g," ");
    const map={video:"Videos",videos:"Videos","chapter videos":"Videos","chapter-wise videos":"Videos","handwritten note":"Handwritten Notes","handwritten notes":"Handwritten Notes",note:"Notes",notes:"Notes","question paper":"Question Bank","question papers":"Question Bank","question bank":"Question Bank","model paper":"Model Papers","model papers":"Model Papers"};
    return map[key]||raw;
  }
  function displayCategory(item){
    if(item.category||item.content_category) return normCategory(item.category||item.content_category);
    return String(item.content_type||"").toLowerCase()==="video"?"Videos":"Notes";
  }
  function pathVisible(item,structure){
    if(!structure?.length || String(item.content_type||"").toLowerCase()==="vacancy") return true;
    const cls=structure.some(x=>x.item_type==="class"&&same(x.name,item.class_name));
    if(!cls) return false;
    const sub=structure.some(x=>x.item_type==="subject"&&same(x.class_name,item.class_name)&&same(normSubject(x.name),normSubject(item.subject)));
    if(!sub) return false;
    const itemType=String(item.content_type||"").toLowerCase();
    const cat=structure.some(x=>x.item_type==="category"&&same(x.class_name,item.class_name)&&same(normSubject(x.subject),normSubject(item.subject))&&(itemType==="video" ? (String(x.system_key||"").toLowerCase()==="videos"||same(normCategory(x.name),"Videos")) : same(normCategory(x.name),normCategory(displayCategory(item)))));
    if(!cat) return false;
    if(itemType==="video" && String(item.chapter_name||"").trim()){
      return structure.some(x=>x.item_type==="chapter"&&same(x.class_name,item.class_name)&&same(normSubject(x.subject),normSubject(item.subject))&&same(x.name,item.chapter_name));
    }
    return true;
  }

  let structure=[];
  try { structure = await sdk.loadContentStructure(); } catch (_) { structure=[]; }
  renderClasses(structure);

  try {
    const rows = await sdk.loadAppContent({ homeOnly: true, contentTypes: ["video"] });
    const visible = rows.filter(x=>pathVisible(x,structure));
    videoEl.innerHTML = visible.length
      ? visible.slice(0, 4).map(videoCard).join("")
      : '<div class="sdkc-app-empty">Admin App से Home के लिए चुने गए long videos यहाँ दिखाई देंगे.</div>';
  } catch (_) {
    videoEl.innerHTML = '<div class="sdkc-app-empty">Selected videos load नहीं हो पाए.</div>';
  }

  sdk.watchAppContent(() => location.reload(), 15000);
  sdk.watchContentStructure(() => location.reload(), 15000);
});
