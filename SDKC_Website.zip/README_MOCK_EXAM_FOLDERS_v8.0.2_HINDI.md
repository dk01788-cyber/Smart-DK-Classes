# Smart DK Classes Website v8.0.2

Mock Test > UPSSSC PET > Test Sets.
Mock Test के अंदर परीक्षा के अनुसार फोल्डर कार्ड; हर फोल्डर में सिर्फ उसी के Published Test Sets.
Folder खाली होने पर Public में नहीं दिखेगा।
General (बिना फोल्डर) Tests "अन्य Mock Tests" में रहेंगे।
डेटाबेस में sdkc_cards.parent_id = Mock Test Hub की ID और sdkc_mock_tests.card_id = Folder ID सेट करें।
पुराने टेस्ट, Result और Answer Review में बदलाव नहीं है।

Cloudflare Build command उदाहरण: unzip -o Smart_DK_Classes_Website_v8.0.2_Mock_Exam_Folders.zip
