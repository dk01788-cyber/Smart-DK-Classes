// v8.0.8: Inline Home question form, no navigation tab or separate Query page.
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("sdkc-student-question-form");
  if (!form) return;
  const msg = document.getElementById("sdkc-question-message");
  const button = form.querySelector('button[type="submit"]');
  const config = window.SMART_DK_CONFIG || {};
  let lastSubmitted = 0;
  let inFlight = false;
  const note = (value, error=false) => {
    msg.textContent = value;
    msg.classList.toggle("sdkc-question-error", error);
  };
  form.addEventListener("submit", async event => {
    event.preventDefault();
    if (inFlight) return;
    const values = new FormData(form);
    const name = String(values.get("student_name") || "").trim().replace(/\s+/g, " ");
    const contact = String(values.get("contact") || "").trim();
    // One optional field; store the supplied contact in the matching database column.
    const email = contact.includes("@") ? contact : "";
    const mobile = contact && !email ? contact.replace(/[ -]/g, "") : "";
    const question = String(values.get("question") || "").trim();
    if (name.length < 2 || name.length > 100) return note("नाम 2 से 100 अक्षर में लिखें।", true);
    if (question.length < 10 || question.length > 3000) return note("प्रश्न 10 से 3000 अक्षर में लिखें।", true);
    if (email && (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))) return note("सही ईमेल आईडी लिखें या फ़ील्ड खाली छोड़ दें।", true);
    if (mobile && !/^\+?[0-9]{7,15}$/.test(mobile)) return note("सही मोबाइल नंबर लिखें या फ़ील्ड खाली छोड़ दें।", true);
    if (Date.now() - lastSubmitted < 30000) return note("एक और प्रश्न भेजने से पहले कुछ समय दें।", true);
    const url = String(config.supabaseUrl || "").replace(/\/$/, "");
    const key = config.supabasePublishableKey;
    if (!url || !key) return note("अभी सर्वर उपलब्ध नहीं है।", true);
    inFlight = true;
    button.disabled = true;
    button.textContent = "भेज रहे हैं…";
    note("");
    try {
      const response = await fetch(`${url}/rest/v1/sdkc_student_queries`, {
        method: "POST",
        headers: {"apikey":key,"Content-Type":"application/json","Prefer":"return=minimal"},
        body: JSON.stringify({student_name:name,email:email||null,mobile:mobile||null,question})
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      lastSubmitted = Date.now();
      form.elements.question.value = "";
      note("✅ आपका प्रश्न Admin तक पहुँच गया है। धन्यवाद!");
    } catch (_) {
      note("प्रश्न नहीं भेजा जा सका। इंटरनेट जाँचकर दोबारा प्रयास करें।", true);
    } finally {
      inFlight = false;
      button.disabled = false;
      button.textContent = "प्रश्न भेजें / Submit";
    }
  });
});
