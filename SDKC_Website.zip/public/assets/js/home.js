document.addEventListener("DOMContentLoaded", async () => {
  const sdk = window.smartdk;
  const videoEl = document.getElementById("home-videos");
  const classEl = document.getElementById("home-class-grid");
  const form = document.getElementById("home-search-form");
  const input = document.getElementById("home-search");

  form?.addEventListener("submit", (e) => {
    e.preventDefault();
    const q = input?.value?.trim() || "";
    location.href = q ? `/library.html?q=${encodeURIComponent(q)}` : "/library.html?search=1";
  });

  const same = (a,b) => String(a||"").trim().toLowerCase() === String(b||"").trim().toLowerCase();
  const orderedUnique = values => {
    const out=[];
    for(const v of values){const x=String(v||"").trim(); if(x && !out.some(y=>same(x,y))) out.push(x);}
    return out;
  };
  const classNo = name => (String(name||"").match(/\d+/)||[""])[0];
  const classHref = name => `/library.html?class=${encodeURIComponent(name)}`;

  async function renderClasses(structure){
    const classes=(structure||[]).filter(x=>x.item_type === "class" && x.is_visible!==false).map(x=>({
      title:x.name,number:classNo(x.name)||"•",sort:Number(x.sort_order)||0,
      href:classHref(x.name),mode:x.sdkc_background_mode,color:x.sdkc_background_color,
      gradient:x.sdkc_gradient_color,image:x.sdkc_background_image
    }));
    if(!classes.length) ["Class 9","Class 10","Class 11","Class 12"].forEach((name,i)=>classes.push({title:name,number:classNo(name),sort:i*10,href:classHref(name)}));
    let customs=[];
    try{const client=sdk.getClient();if(client){const {data,error}=await client.from("sdkc_cards").select("*").is("parent_id",null).eq("is_published",true).eq("show_on_home",true).order("sort_order");if(!error)customs=data||[];}}catch(_){}
    const styleOf=x=>{
      const c=/^#[a-f0-9]{6}$/i.test(x.color||"")?x.color:"#2563eb";
      const g=/^#[a-f0-9]{6}$/i.test(x.gradient||"")?x.gradient:"#0f766e";
      if(x.mode==="image"&&/^https:\/\//.test(x.image||"")) return `background:linear-gradient(#0006,#0006),url('${String(x.image).replace(/['"<>]/g,"")}') center/cover;color:white`;
      if(x.mode==="gradient")return `background:linear-gradient(135deg,${c},${g});color:white`;
      return x.color?`background:${c};color:white`:"";
    };
    const customItems=customs.filter(x=>String(x.title||"").trim().toLowerCase()!=="general library").map(x=>({title:x.title,number:x.card_type==='mock-hub'?'📝':'★',sort:Number(x.sort_order)||999,
      href:x.card_type==='mock-hub'?'/mock-tests.html':`/direct.html?folder=${encodeURIComponent(x.id)}`,
      mode:x.background_mode,color:x.background_color,gradient:x.gradient_color,image:x.background_image}));
    // Keep Class 9/10/11/12 in one main Academic Classes card.
    // Admin-managed class data is unchanged; each class keeps its own subject path.
    const academic = {title:'Academic Classes',number:'🎓',sort:-10000,kind:'academic',
      href:'/library.html?academic=1',mode:'gradient',color:'#245fec',gradient:'#5c36cf'};
    const all=[academic,...customItems].sort((a,b)=>a.sort-b.sort||a.title.localeCompare(b.title));
    if(!classEl)return;
    classEl.innerHTML=all.map(x=>`<a class="sdkc-app-class-card ${x.kind==='academic'?'sdkc-academic-main-card':''}" style="${styleOf(x)}" href="${x.href}"><span>${sdk.escapeHtml(x.number)}</span><div><b>${sdk.escapeHtml(x.title)}</b><small>${x.kind==='academic'?'Class 9 • 10 • 11 • 12':'Explore →'}</small></div><strong>›</strong></a>`).join("");
  }

  function videoHref(item) {
    return `/video-player.html?id=${encodeURIComponent(item.id || "")}`;
  }

  function videoCard(item) {
    const meta = [item.class_name, item.subject, item.chapter_name].filter(Boolean).join(" • ") || "Smart DK Classes";
    const thumb = item.thumbnail_url || "";
    return `<a class="sdkc-app-content-card sdkc-app-video-row" href="${videoHref(item)}">
      <div class="sdkc-app-content-icon sdkc-video-icon">${thumb ? `<img src="${sdk.escapeHtml(thumb)}" alt="">` : "▶"}</div>
      <div class="sdkc-app-content-copy"><span>VIDEO CLASS</span><b>${sdk.escapeHtml(item.title || "Video Class")}</b><small>${sdk.escapeHtml(meta)}</small></div>
      <strong class="sdkc-app-row-arrow">›</strong>
    </a>`;
  }

  function normSubject(value){
    const raw=String(value||"").trim(), key=raw.toLowerCase().replace(/\s+/g," ");
    const map={math:"Mathematics",maths:"Mathematics",mathematics:"Mathematics",sst:"Social Science","social studies":"Social Science"};
    return map[key]||raw;
  }
  function normCategory(value){
    const raw=String(value||"").trim(), key=raw.toLowerCase().replace(/\s+/g," ");
    const map={video:"Videos",videos:"Videos","chapter videos":"Videos","chapter-wise videos":"Videos","handwritten note":"Handwritten Notes","handwritten notes":"Handwritten Notes",note:"Notes",notes:"Notes","question paper":"Question Bank","question papers":"Question Bank","question bank":"Question Bank","model paper":"Model Papers","model papers":"Model Papers"};
    return map[key]||raw;
  }
  function displayCategory(item){
    if(item.category||item.content_category) return normCategory(item.category||item.content_category);
    return String(item.content_type||"").toLowerCase()==="video"?"Videos":"Notes";
  }
  function pathVisible(item,structure){
    if(!structure?.length || String(item.content_type||"").toLowerCase()==="vacancy") return true;
    const cls=structure.some(x=>x.item_type==="class"&&same(x.name,item.class_name));
    if(!cls) return false;
    const sub=structure.some(x=>x.item_type==="subject"&&same(x.class_name,item.class_name)&&same(normSubject(x.name),normSubject(item.subject)));
    if(!sub) return false;
    const itemType=String(item.content_type||"").toLowerCase();
    const cat=structure.some(x=>x.item_type==="category"&&same(x.class_name,item.class_name)&&same(normSubject(x.subject),normSubject(item.subject))&&(itemType==="video" ? (String(x.system_key||"").toLowerCase()==="videos"||same(normCategory(x.name),"Videos")) : same(normCategory(x.name),normCategory(displayCategory(item)))));
    if(!cat) return false;
    if(itemType==="video" && String(item.chapter_name||"").trim()){
      return structure.some(x=>x.item_type==="chapter"&&same(x.class_name,item.class_name)&&same(normSubject(x.subject),normSubject(item.subject))&&same(x.name,item.chapter_name));
    }
    return true;
  }

  let structure=[];
  try { structure = await sdk.loadContentStructure(); } catch (_) { structure=[]; }
  await renderClasses(structure);

  try {
    const rows = await sdk.loadAppContent({ homeOnly: true, contentTypes: ["video"] });
    const visible = rows.filter(x=>pathVisible(x,structure));
    videoEl.innerHTML = visible.length
      ? visible.slice(0, 4).map(videoCard).join("")
      : '<div class="sdkc-app-empty">Admin App से Home के लिए चुने गए long videos यहाँ दिखाई देंगे.</div>';
  } catch (_) {
    videoEl.innerHTML = '<div class="sdkc-app-empty">Selected videos load नहीं हो पाए.</div>';
  }

  sdk.watchAppContent(() => location.reload(), 15000);
  sdk.watchContentStructure(() => location.reload(), 15000);
});
