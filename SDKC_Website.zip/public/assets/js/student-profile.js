/* Smart DK Classes opt-in local learner profile. Do NOT send phone/photo to server. */
(() => {
  'use strict';
  const STORAGE='sdkc.student.profile.2026';
  const getBrowser=()=>{try{return JSON.parse(localStorage.getItem(STORAGE)||'null')||{};}catch(_){return {};}};
  const get=()=>{
    try{if(window.SDKCAndroidProfile?.getProfile){
      let p=JSON.parse(window.SDKCAndroidProfile.getProfile());if(p&&p.name)return {...p,native:true};
    }}catch(_){}
    return getBrowser();
  };
  const esc=s=>String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const avatar=p=>p.photo&&/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(p.photo)?`<img src="${p.photo}" alt="Student avatar" style="width:68px;height:68px;border-radius:50%;object-fit:cover">`:'<span style="font-size:40px">👤</span>';
  const summary=()=>{let p=get();if(!p.name)return '<p class="sdkc-ext-muted">Result में नाम दिखाने के लिए <a href="/student-profile.html">My Profile</a> पर जाएँ।</p>';
    return `<div class="sdkc-ext-card" style="display:flex;align-items:center;gap:14px">${avatar(p)}<div><strong>${esc(p.name)}</strong><div class="sdkc-ext-muted">Student profile ${p.share?'• Name/result sharing enabled':'• Local only'}</div><a href="${p.native?'#sdkc-edit-native':'/student-profile.html'}" ${p.native?'title="Edit in Smart DK Classes Android Home → My Profile"':''}>${p.native?'Edit from App Home → My Profile':'Edit Profile'}</a></div></div>`;};
  const saveBrowser=async(obj)=>{
    if(!obj.name||obj.name.trim().length<2||obj.name.trim().length>60)throw Error('नाम 2–60 अक्षर का लिखें।');
    if(obj.mobile&&!/^\d{10}$/.test(obj.mobile))throw Error('मोबाइल नंबर खाली रखें या 10 अंक लिखें।');
    let old=getBrowser();
    const profile={name:obj.name.trim(),mobile:obj.mobile||'',photo:obj.photo||'',share:!!obj.share,
      profile_id:old.profile_id||crypto.randomUUID(),profile_token:old.profile_token||crypto.randomUUID()};
    localStorage.setItem(STORAGE,JSON.stringify(profile));
    // Withdraw -> private profile & linked attempts deleted server-side using random token.
    if(window.smartdk?.getClient()){
      const sb=window.smartdk.getClient();
      const {error}=await sb.rpc('sdkc_save_student_profile',{
        p_id:profile.profile_id,p_token:profile.profile_token,p_name:profile.name,p_consent:profile.share
      });
      if(error&&profile.share)throw Error('Profile इस browser में सेव है, लेकिन Admin से Sync नहीं हुआ: '+error.message);
    }
    return profile;
  };
  window.SDKCStudentProfile={get,summary,saveBrowser,escape:esc};
  if(!document.getElementById('sdkc-student-profile-form'))return;
  const root=document.getElementById('sdkc-student-profile-form');let p=get();
  if(p.native){root.innerHTML='<div class="sdkc-ext-card"><h2>My Profile</h2><p>आपकी प्रोफाइल Android App में सुरक्षित है। नाम, मोबाइल और फोटो बदलने के लिए App Home → My Profile / Edit खोलें।</p><a href="/mock-tests.html">Back to Mock Tests</a></div>';return;}
  root.innerHTML=`<form id="sdkc-profile-edit" class="sdkc-ext-card" style="display:grid;gap:10px;max-width:540px">
     <h1>My Profile</h1><div style="text-align:center" id="sdkc-photo-view">${avatar(p)}</div>
     <label>Profile Photo <input id="sdkc-p-photo" type="file" accept="image/png,image/jpeg,image/webp"></label>
     <button type="button" class="sdkc-ext-btn alt" id="sdkc-p-remove">Remove Photo</button>
     <label>Your Name * <input required minlength="2" maxlength="60" id="sdkc-p-name" autocomplete="name" value="${esc(p.name)}"></label>
     <label>Mobile Number <input id="sdkc-p-mobile" maxlength="10" inputmode="numeric" pattern="[0-9]{10}" value="${esc(p.mobile)}"></label>
     <p class="sdkc-ext-muted">No Login • No OTP • Mobile and photo remain on your own device/browser.</p>
     <label><input type="checkbox" id="sdkc-p-share" ${p.share?'checked':''}> Share my name and mock-test scores with Smart DK Classes Admin. Photo and mobile will not be shared.</label>
     <button class="sdkc-ext-btn" type="submit">Save Profile</button>
     <p id="sdkc-p-msg" role="status"></p>
     <a href="/mock-tests.html">Back to Mock Tests</a>
    </form>`;
  root.querySelector('#sdkc-p-remove').addEventListener('click',()=>{p.photo='';root.querySelector('#sdkc-photo-view').innerHTML=avatar(p);});
  root.querySelector('#sdkc-p-photo').addEventListener('change',e=>{
    const file=e.target.files[0];if(!file)return;
    if(file.size>4_000_000){alert('4 MB से छोटी फोटो चुनें।');return;}
    const img=new Image();const u=URL.createObjectURL(file);
    img.onload=()=>{let c=document.createElement('canvas');let ratio=Math.min(1,220/Math.max(img.width,img.height));c.width=Math.max(1,Math.floor(img.width*ratio));c.height=Math.max(1,Math.floor(img.height*ratio));c.getContext('2d').drawImage(img,0,0,c.width,c.height);p.photo=c.toDataURL('image/jpeg',0.75);URL.revokeObjectURL(u);root.querySelector('#sdkc-photo-view').innerHTML=avatar(p);};img.src=u;
  });
  root.querySelector('#sdkc-profile-edit').addEventListener('submit',async(e)=>{e.preventDefault();const msg=root.querySelector('#sdkc-p-msg');
    try{await saveBrowser({...p,name:root.querySelector('#sdkc-p-name').value,mobile:root.querySelector('#sdkc-p-mobile').value,share:root.querySelector('#sdkc-p-share').checked});msg.textContent='✓ Profile saved';msg.style.color='green';}
    catch(err){msg.textContent=err.message;msg.style.color='red';}
  });
})();
