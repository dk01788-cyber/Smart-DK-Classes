window.addEventListener('DOMContentLoaded',async()=>{
  const text=(id,t)=>{document.getElementById(id).textContent=t;};
  try{
    const sb=window.smartdk?.getClient?.();if(!sb)throw Error('Supabase unavailable');
    const {data,error}=await sb.from('site_settings').select('android_app_version,android_apk_path,android_apk_notes,android_apk_size').eq('id',1).maybeSingle();
    if(error)throw error;
    if(!data?.android_apk_path)throw Error('Admin ने अभी नया APK publish नहीं किया है।');
    const path=String(data.android_apk_path).replace(/^\/+/, '');
    if(path.split('/').some(x=>x==='..'||!x))throw Error('Invalid APK path');
    const base=String(window.SMART_DK_CONFIG.supabaseUrl||'').replace(/\/$/,'');
    const a=document.getElementById('sdkc-update-download');a.href=base+'/storage/v1/object/public/app-downloads/'+path.split('/').map(encodeURIComponent).join('/');
    a.style.display='inline-block';a.setAttribute('download','');
    text('sdkc-update-ver','Latest version '+(data.android_app_version||'Available'));
    text('sdkc-update-notes',data.android_apk_notes||'Official Smart DK Classes Android release.');
    text('sdkc-update-status','✓ Admin द्वारा अपलोड की गई फाइल से डाउनलोड करें।');
  }catch(e){text('sdkc-update-status','अभी APK लिंक उपलब्ध नहीं है: '+e.message);text('sdkc-update-ver','Please check again later.');}
});
