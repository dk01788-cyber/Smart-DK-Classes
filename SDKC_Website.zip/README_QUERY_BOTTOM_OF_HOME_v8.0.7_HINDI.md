# Smart DK Classes Website v8.0.7 — Home के नीचे प्रश्न फॉर्म

- Home page में Selected Video Classes के बाद inline **अपना प्रश्न पूछें** Form दिखाई देता है।
- किसी अलग Query Menu / Bottom Tab की आवश्यकता नहीं।
- नाम और प्रश्न अनिवार्य; Email/Mobile optional।
- प्रश्न Supabase public.sdkc_student_queries में सुरक्षित INSERT; पढ़ना सिर्फ Admin को।
- Form तथा Privacy Policy दोनों Website और Android के लिए अपडेट किए गए।
- वेबसाइट और Public App एक ही Admin Inbox में प्रश्न भेजते हैं।
- Deploy: वेबसाइट ZIP को Website GitHub repo में रखें और Cloudflare Pages Build में latest ZIP चुनें।
