# Smart DK Classes Website v8.0.4 — Remove General Library Home Card

- Home पर पहले से हार्डकोडेड General Library कार्ड हटाया गया है।
- अन्य Home Cards (GK, Reasoning, Mock Test, Class 9–12) और उनके Links/Design सुरक्षित हैं।
- Direct Content, Folder और PDF डेटा को डिलीट नहीं किया गया।
- Service Worker cache version और Home JS asset version बढ़ाया गया ताकि पुराना Home न दिखे।
- केवल source ZIP है; GitHub पर upload और Cloudflare deployment आवश्यक है।
