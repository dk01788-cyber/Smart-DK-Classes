# Website v8.0.5 – Academic Classes Home

- Academic Classes (9–12) अब Home पर एक पूर्ण-चौड़ाई मुख्य कार्ड है।
- कार्ड खोलने पर केवल Class 9–12, फिर Subject → Category → Content।
- General Library Home कार्ड हटाने वाला v8.0.4 सुधार सुरक्षित है।
- GK, Reasoning, Mock Test, custom folders, Home videos, search व banner अपरिवर्तित।
- सर्वर/डेटाबेस से सामग्री नहीं मिटाई गई।
- GitHub में ZIP अपलोड और Cloudflare Deployment अभी जरूरी; यह एक तैयार Source ZIP है।
