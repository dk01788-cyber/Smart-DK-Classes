# Smart DK Classes वेबसाइट v8.0.8 — Query Form में एक Contact फील्ड

Home Page पर वीडियो के बाद छात्र Query Form। नाम व प्रश्न पर *, एक फील्ड "मोबाइल नंबर या ईमेल आईडी", कोई Optional लेबल नहीं। दोनों संपर्क विवरण खाली भी छोड़ सकते हैं। Submit करते समय दिया हुआ Email या Mobile अपने-अपने मौजूदा Supabase कॉलम में जाएगा। बाकी वेबसाइट, विषय, PDF, Mock Test और Privacy Policy पहले जैसे हैं। ZIP GitHub website repository में अपलोड करें; Cloudflare build command में v8.0.8 चुना जाना जरूरी है।
