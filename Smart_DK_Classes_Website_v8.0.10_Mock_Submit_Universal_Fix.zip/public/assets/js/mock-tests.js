/* Smart DK Classes: anonymous mock tests, instant result and optional question review. */
(() => {
  'use strict';
  const target = document.getElementById('test-app');
  const sdk = window.smartdk;
  const sb = sdk?.getClient();
  const esc = sdk?.escapeHtml || (s => String(s));
  const params = new URLSearchParams(location.search);
  const state = {test:null,answers:{},position:0,result:null,filter:'all',remaining:0,timer:null,locked:false};
  const status = (s) => {target.innerHTML = `<div class="sdkc-ext-status" role="status">${esc(s)}</div>`;};
  const button = (text,act,cl='sdkc-ext-btn') => `<button class="${cl}" data-act="${act}">${esc(text)}</button>`;
  const safeId = id => /^[0-9a-f-]{36}$/i.test(String(id||''));
  const fmt = n => Number(n||0).toLocaleString('hi-IN',{maximumFractionDigits:2});
  async function call(name, args){const {data,error}=await sb.rpc(name,args);if(error)throw new Error(error.message);return data;}
  // One top-level Mock Test card, followed by exam-specific folders.
  // Published tests are never moved/deleted by changing their display location.
  async function list(){
    status('मॉक टेस्ट लोड हो रहे हैं…');
    const {data,error}=await sb.from('sdkc_mock_tests').select('id,title,description,duration_minutes,sort_order,card_id').eq('is_published',true).order('sort_order').order('created_at',{ascending:false});
    if(error)throw error;
    const result=await sb.from('sdkc_cards').select('id,title,card_type,parent_id,sort_order,is_published').eq('is_published',true).order('sort_order');
    if(result.error)throw result.error;
    const cards=result.data||[],tests=data||[];
    const hub=cards.find(c=>c.card_type==='mock-hub');
    if(!hub){status('Mock Test सेक्शन अभी उपलब्ध नहीं है।');return;}
    const byId=new Map(cards.map(c=>[c.id,c]));
    const children=id=>cards.filter(c=>c.card_type==='folder' && c.parent_id===id).sort((a,b)=>a.sort_order-b.sort_order||a.title.localeCompare(b.title));
    const belowHub=(id)=>{
      const visited=new Set(); let card=byId.get(id);
      while(card&&!visited.has(card.id)){
        if(card.parent_id===hub.id)return true;
        visited.add(card.id);card=byId.get(card.parent_id);
      }
      return false;
    };
    const nearestFolder=(test)=>belowHub(test.card_id)?test.card_id:null;
    const directTests=id=>tests.filter(t=>nearestFolder(t)===id);
    const descendants=id=>{
      const seen=new Set();
      const count=(fid)=>{if(seen.has(fid))return 0; seen.add(fid);return directTests(fid).length+children(fid).reduce((total,c)=>total+count(c.id),0);};
      return count(id);
    };
    const folderCard=c=>`<a class="sdkc-ext-folder" href="?folder=${encodeURIComponent(c.id)}" aria-label="${esc(c.title)} फोल्डर खोलें"><span class="sdkc-ext-folder-icon">📁</span><strong>${esc(c.title)}</strong><span class="sdkc-ext-muted">${fmt(descendants(c.id))} Mock Tests</span><span class="sdkc-ext-folder-open">सेट देखें →</span></a>`;
    const testCard=t=>`<article class="sdkc-ext-card"><div class="sdkc-ext-card-title">${esc(t.title)}</div><p class="sdkc-ext-muted">${esc(t.description||'Online Practice Test')} · ${t.duration_minutes?fmt(t.duration_minutes)+' मिनट':'बिना समय सीमा'}</p><a class="sdkc-ext-btn" href="?test=${encodeURIComponent(t.id)}">Start Test</a></article>`;
    const folderId=params.get('folder');
    const validFolder=folderId&&safeId(folderId)&&byId.get(folderId)?.card_type==='folder'&&belowHub(folderId);
    if(folderId && folderId!=='general' && !validFolder){status('यह Mock Test Folder उपलब्ध नहीं है।');return;}
    if(!folderId){
      const top=children(hub.id).filter(c=>descendants(c.id)>0);
      const others=directTests(null);
      const folderTiles=[...top.map(folderCard),...(others.length?[`<a class="sdkc-ext-folder" href="?folder=general"><span class="sdkc-ext-folder-icon">📁</span><strong>अन्य Mock Tests</strong><span class="sdkc-ext-muted">${fmt(others.length)} Mock Tests</span><span class="sdkc-ext-folder-open">सेट देखें →</span></a>`]:[])];
      target.innerHTML=`<h1>📝 Mock Test Center</h1><p>अपनी परीक्षा का फोल्डर चुनें। Final Submit के बाद Result और Answer Review देखें।</p>${folderTiles.length?`<div class="sdkc-ext-folders">${folderTiles.join('')}</div>`:'<p class="sdkc-ext-muted">अभी कोई Mock Test प्रकाशित नहीं हुआ है।</p>'}`;
      return;
    }
    const folder=validFolder?byId.get(folderId):null;
    const subs=folder?children(folder.id).filter(c=>descendants(c.id)>0):[];
    const listOfTests=folder?directTests(folder.id):directTests(null);
    const heading=folder?folder.title:'अन्य Mock Tests';
    target.innerHTML=`<nav aria-label="Breadcrumb"><a class="sdkc-ext-back" href="/mock-tests.html">← सभी परीक्षाएँ</a></nav><h1>📁 ${esc(heading)}</h1><p class="sdkc-ext-muted">${fmt(folder?descendants(folder.id):listOfTests.length)} उपलब्ध सेट</p>${subs.length?`<div class="sdkc-ext-folders">${subs.map(folderCard).join('')}</div>`:''}${listOfTests.length?`<div class="sdkc-ext-grid">${listOfTests.map(testCard).join('')}</div>`:!subs.length?'<p class="sdkc-ext-muted">अभी इस फोल्डर में कोई प्रकाशित टेस्ट नहीं है।</p>':''}`;
  }
  function clearTimer(){if(state.timer){clearInterval(state.timer);state.timer=null;}}
  function timerString(){const s=Math.max(0,state.remaining);return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;}
  function startTimer(){
    clearTimer();if(!state.test.duration_minutes)return;
    state.remaining=state.test.duration_minutes*60;
    state.timer=setInterval(()=>{state.remaining=Math.max(0,state.remaining-1);const t=target.querySelector('#sdkc-timer');if(t)t.textContent=timerString();if(state.remaining===0){clearTimer();submit(true);}},1000);
  }
  async function start(id){
    status('प्रश्न लोड हो रहे हैं…');
    state.test=await call('sdkc_start_test',{p_test:id});state.answers={};state.position=0;state.result=null;state.locked=false;
    try{sessionStorage.removeItem(`sdkc-mock-result-${id}`);}catch(_){}
    if(!state.test.questions.length){status('इस टेस्ट में अभी प्रश्न नहीं हैं।');return;}
    showQuestion();startTimer();
  }
  // SVG/font-based block glyphs (■■■) don't survive all mobile fonts, and
  // HTML collapses their spacing. Turn existing text-only PET charts into
  // responsive CSS columns so both website and in-app WebView render them.
  function renderQuestionContent(raw){
    const text=String(raw||'').replace(/\r\n?/g,'\n');
    const lines=text.split('\n');
    const plain=()=>`<div class="sdkc-ext-question-prose">${esc(text)}</div>`;
    if(!/ग्राफ/.test(lines[0]||''))return plain();
    const parsed=[];
    const used=new Set();
    for(let i=1;i<lines.length;i++){
      // CSV contains: `2022: ■■■■■■ (60)` or `2022  ■■■■■■  60`.
      const match=lines[i].trim().match(/^(.+?)\s+([■█▇▆▓]{2,})\s+\(?([0-9][0-9,]*(?:\.[0-9]+)?)\)?\s*$/u);
      if(!match)continue;
      const name=match[1].replace(/[:：\s]+$/u,'').trim();
      const value=Number(match[3].replace(/,/g,''));
      if(!name||!Number.isFinite(value)||value<0)continue;
      parsed.push({name,value});used.add(i);
    }
    if(parsed.length<3||parsed.length>12)return plain();
    const maxValue=Math.max(...parsed.map(d=>d.value));
    if(!maxValue)return plain();
    const unit=Math.pow(10,Math.floor(Math.log10(maxValue/4||1)));
    const step=Math.ceil(maxValue/4/unit)*unit;
    const maxTick=step*4;
    const title=lines[0].replace(/^प्रश्न\s*\d+\s*[.।:]\s*/u,'').replace(/\s*प्रत्येक\s+[■█▇▆▓]\s*=.*$/u,'').trim();
    const question=lines.slice(1).filter((_,i)=>!used.has(i+1)).join('\n').trim();
    const summary=parsed.map(d=>`${d.name}: ${d.value}`).join(', ');
    const bars=parsed.map(d=>{
      const percentage=Math.max(2,100*d.value/maxTick);
      return `<div class="sdkc-ext-chart-item" title="${esc(d.name)}: ${fmt(d.value)}">
        <div class="sdkc-ext-chart-barbox" style="--sdkc-h:${percentage.toFixed(3)}%"><span class="sdkc-ext-chart-value">${fmt(d.value)}</span><span class="sdkc-ext-chart-bar" style="height:${percentage.toFixed(3)}%"></span></div>
        <span class="sdkc-ext-chart-label">${esc(d.name)}</span></div>`;
    }).join('');
    const ticks=Array.from({length:5},(_,i)=>fmt(maxTick*(4-i)/4));
    return `<div class="sdkc-ext-chart-heading">${esc(title)}</div>
      <figure class="sdkc-ext-chart" role="group" aria-label="${esc(title)}. ${esc(summary)}">
        <div class="sdkc-ext-chart-area"><div class="sdkc-ext-chart-axis" aria-hidden="true">${ticks.map(v=>`<span>${v}</span>`).join('')}</div>
          <div class="sdkc-ext-chart-bars" style="--sdkc-bars:${parsed.length}">${bars}</div></div>
        <figcaption class="sdkc-ext-chart-caption">स्तंभ आरेख • ${parsed.length} श्रेणियाँ</figcaption></figure>
      ${question?`<div class="sdkc-ext-question-prose sdkc-ext-question-prompt">${esc(question)}</div>`:''}`;
  }
  function showQuestion(){
    if(!state.test || state.locked)return;
    const qs=state.test.questions,q=qs[state.position],sel=state.answers[q.id];
    target.innerHTML=`<div class="sdkc-ext-intro"><h1>${esc(state.test.title)}</h1><span class="sdkc-ext-timer" id="sdkc-timer">${state.test.duration_minutes?timerString():'No Timer'}</span></div>
      <p class="sdkc-ext-muted">प्रश्न ${state.position+1} / ${qs.length} · उत्तर दिए: ${Object.keys(state.answers).length}</p>
      <div class="sdkc-ext-card"><h2 class="sdkc-ext-question-number">Q${state.position+1}.</h2>${renderQuestionContent(q.question_text)}<div>${q.options.map((o,i)=>`<label class="sdkc-ext-choice"><input type="radio" name="sdkc-answer" value="${i}" ${sel===i?'checked':''}><span>${String.fromCharCode(65+i)}. ${esc(o)}</span></label>`).join('')}</div><div class="sdkc-ext-actions">${button('उत्तर हटाएँ','clear','sdkc-ext-btn alt')}</div></div>
      <div class="sdkc-ext-actions">${button('← Previous','prev','sdkc-ext-btn alt')}${button('Next →','next')}${button('Final Submit','final','sdkc-ext-btn warn')}</div>
      <div class="sdkc-ext-card"><p class="sdkc-ext-muted">प्रश्न चुनें:</p><div class="sdkc-ext-palette">${qs.map((x,i)=>`<button data-jump="${i}" class="${i===state.position?'active':''} ${state.answers[x.id]!==undefined?'done':''}" aria-label="Question ${i+1}">${i+1}</button>`).join('')}</div></div>`;
  }
  // A page-owned confirmation works in ordinary browsers and Android WebView,
  // including older installed Public App APKs with no WebChromeClient JS dialogs.
  function closeConfirm(){
    const overlay=target.querySelector('#sdkc-mock-confirm-overlay');
    if(overlay)overlay.remove();
  }
  function showConfirm(kind){
    if(!state.test || (state.locked && kind==='submit'))return;
    closeConfirm();
    const isSubmit=kind==='submit';
    const unanswered=Math.max(0,state.test.questions.length-Object.keys(state.answers).length);
    const message=isSubmit
      ? `क्या आप Final Submit करना चाहते हैं? ${unanswered} प्रश्न छोड़े गए हैं। इसके बाद उत्तर बदले नहीं जा सकेंगे।`
      : 'क्या आप नया Mock Test शुरू करना चाहते हैं? पिछले उत्तर हट जाएँगे।';
    target.insertAdjacentHTML('beforeend', `<div id="sdkc-mock-confirm-overlay" class="sdkc-ext-modal-overlay" role="presentation">
      <div role="dialog" aria-modal="true" aria-labelledby="sdkc-mock-confirm-title" aria-describedby="sdkc-mock-confirm-desc" class="sdkc-ext-modal">
        <h2 id="sdkc-mock-confirm-title">${isSubmit?'Final Submit करें?':'टेस्ट दोबारा शुरू करें?'}</h2>
        <p id="sdkc-mock-confirm-desc">${esc(message)}</p>
        <div class="sdkc-ext-actions">
          ${button('रद्द करें','cancel-dialog','sdkc-ext-btn alt')}
          ${button(isSubmit?'हाँ, Submit करें':'हाँ, नया टेस्ट शुरू करें',isSubmit?'confirm-final':'confirm-retake',isSubmit?'sdkc-ext-btn warn':'sdkc-ext-btn')}
        </div>
      </div></div>`);
    target.querySelector('[data-act="cancel-dialog"]')?.focus();
  }
  document.addEventListener('keydown', e=>{
    if(e.key==='Escape' && target.querySelector('#sdkc-mock-confirm-overlay')){
      e.preventDefault();closeConfirm();
    }
  });
  async function submit(auto=false){
    if(state.locked||!state.test)return;
    if(!auto){showConfirm('submit');return;}
    closeConfirm();
    state.locked=true;clearTimer();status('Result तैयार हो रहा है…');
    try{
      const data=await call('sdkc_finish_test',{p_test:state.test.id,p_answers:state.answers});
      state.result=data;state.filter='all';showResult();
      // No student account, so this machine only keeps the most recent result for reload/review.
      try{sessionStorage.setItem(`sdkc-mock-result-${state.test.id}`,JSON.stringify({title:state.test.title,result:data}));}catch(_){}
    }catch(err){state.locked=false;status(`Result नहीं मिल सका: ${err.message}. कृपया Retry करें।`);target.insertAdjacentHTML('beforeend',button('Retry Result','retry'));window.scrollTo(0,0);}
  }
  function showResult(){
    const r=state.result;if(!r)return;const percent=r.max_score>0?Math.max(0,r.score/r.max_score*100):0;
    target.innerHTML=`<h1>✅ ${esc(state.test.title)} — Result</h1><p>Final Submit सफल। नीचे अपना प्रदर्शन देखें।</p>
     <div class="sdkc-ext-grid"><div class="sdkc-ext-metric">Total<b>${fmt(r.total)}</b></div><div class="sdkc-ext-metric">Attempted<b>${fmt(r.attempted)}</b></div><div class="sdkc-ext-metric">✅ Correct<b>${fmt(r.correct)}</b></div><div class="sdkc-ext-metric">❌ Wrong<b>${fmt(r.wrong)}</b></div><div class="sdkc-ext-metric">Unattempted<b>${fmt(r.unattempted)}</b></div><div class="sdkc-ext-metric">Accuracy<b>${fmt(r.accuracy)}%</b></div><div class="sdkc-ext-metric">Score<b>${fmt(r.score)} / ${fmt(r.max_score)}</b></div><div class="sdkc-ext-metric">Marks %<b>${fmt(percent)}%</b></div></div>
     <div class="sdkc-ext-actions">${button('🔍 Review Answers','review')}${button('Retake Test','retake','sdkc-ext-btn alt')}<a class="sdkc-ext-btn alt" href="/mock-tests.html">All Tests</a></div>
     <p class="sdkc-ext-muted">Accuracy = Correct / Attempted × 100. Score में टेस्ट की Negative Marking शामिल है।</p>`;
    window.scrollTo(0,0);
  }
  function showReview(){
    const r=state.result; if(!r)return;
    const all=r.review||[], filtered=all.map((q,i)=>({...q,number:i+1})).filter(q=>state.filter==='all'||q.status===state.filter);
    target.innerHTML=`<h1>Answer Review</h1><p>${esc(state.test.title)} · सही ${r.correct} · गलत ${r.wrong} · छोड़े ${r.unattempted}</p>
      <div class="sdkc-ext-actions">${[['all','सभी'],['correct','✅ सही'],['wrong','❌ गलत'],['unattempted','⭕ छोड़े गए']].map(([k,t])=>button(t+' ('+(k==='all'?r.total:k==='correct'?r.correct:k==='wrong'?r.wrong:r.unattempted)+')','filter-'+k,'sdkc-ext-filter '+(state.filter===k?'active':''))).join('')}</div>
      <div role="region" aria-live="polite">${filtered.map(q=>`<article class="sdkc-ext-card sdkc-ext-${q.status==='correct'?'good':q.status==='wrong'?'bad':'skip'}"><div class="sdkc-ext-review-question"><strong>Q${q.number}.</strong>${renderQuestionContent(q.question_text)}</div><p class="sdkc-ext-small"><strong>स्थिति:</strong> ${q.status==='correct'?'✅ सही':q.status==='wrong'?'❌ गलत':'⭕ छोड़ा हुआ'}</p><div class="sdkc-ext-answer"><strong>आपका उत्तर:</strong> ${q.selected_index==null?'उत्तर नहीं दिया':esc(String.fromCharCode(65+q.selected_index)+'. '+q.options[q.selected_index])}</div>${r.show_answers?`<div class="sdkc-ext-answer"><strong>सही उत्तर:</strong> ${esc(String.fromCharCode(65+q.correct_index)+'. '+q.options[q.correct_index])}</div>${q.explanation?`<p><strong>Explanation:</strong> ${esc(q.explanation)}</p>`:''}`:'<p class="sdkc-ext-muted">इस टेस्ट में Admin ने Answer Key छिपाई है।</p>'}</article>`).join('')||'<div class="sdkc-ext-status">इस फिल्टर में कोई प्रश्न नहीं है।</div>'}</div>
     <div class="sdkc-ext-actions">${button('← Result पर जाएँ','result','sdkc-ext-btn alt')}${button('फिर से Test दें','retake','sdkc-ext-btn alt')}</div>`;
    window.scrollTo(0,0);
  }
  target.addEventListener('change',e=>{if(e.target.matches('input[name="sdkc-answer"]')&&!state.locked){state.answers[state.test.questions[state.position].id]=Number(e.target.value);showQuestion();}});
  target.addEventListener('click',e=>{
    const jump=e.target.closest('[data-jump]');if(jump&&!state.locked){state.position=Number(jump.dataset.jump);showQuestion();return;}
    const b=e.target.closest('[data-act]');if(!b)return;
    const act=b.dataset.act;
    if(act==='next'){state.position=Math.min(state.position+1,state.test.questions.length-1);showQuestion();}
    else if(act==='prev'){state.position=Math.max(0,state.position-1);showQuestion();}
    else if(act==='clear'){delete state.answers[state.test.questions[state.position].id];showQuestion();}
    else if(act==='final')submit(false);
    else if(act==='confirm-final')submit(true);
    else if(act==='cancel-dialog')closeConfirm();
    else if(act==='confirm-retake'){closeConfirm();start(state.test.id).catch(e=>status(e.message));}
    else if(act==='retry')submit(true);
    else if(act==='review'){state.filter='all';showReview();}
    else if(act==='result')showResult();
    else if(act.startsWith('filter-')){state.filter=act.slice(7);showReview();}
    else if(act==='retake')showConfirm('retake');
  });
  if(!sb){status('Supabase connection उपलब्ध नहीं है।');return;}
  const testId=params.get('test');if(testId){
    if(!safeId(testId)){status('अमान्य Test ID।');return;}
    let saved=null;try{saved=JSON.parse(sessionStorage.getItem(`sdkc-mock-result-${testId}`)||'null');}catch(_){}
    if(saved?.result && saved?.title){state.test={id:testId,title:saved.title};state.result=saved.result;state.locked=true;showResult();}
    else start(testId).catch(e=>status('Test खोलने में समस्या: '+e.message));
  }else list().catch(e=>status('Mock Tests नहीं मिल सके: '+e.message));
})();
